import { Permission } from '@/common/lib/authz';

export type AppNavItem = {
  path: string;
  label: string;
  permission: Permission;
  description: string;
};

export const appRoutes: { main: AppNavItem[]; mechanic: AppNavItem[] } = {
  main: [
    {
      path: '/dashboard',
      label: 'Dashboard',
      permission: 'dashboard:view',
      description: 'Ringkasan operasional harian dan KPI servis.',
    },
    {
      path: '/customers',
      label: 'Pelanggan',
      permission: 'customers:view',
      description: 'Data pemilik kendaraan, kontak, dan histori relasi pelanggan.',
    },
    {
      path: '/vehicles',
      label: 'Kendaraan',
      permission: 'vehicles:view',
      description: 'Data unit, nomor rangka, plat, kilometer, dan histori servis.',
    },
    {
      path: '/work-orders',
      label: 'Work Order',
      permission: 'work-orders:view',
      description: 'Daftar WO aktif dan entry point pembuatan WO baru.',
    },
    {
      path: '/services',
      label: 'Servis',
      permission: 'services:view',
      description: 'Board progres servis, timeline, dan tindakan operasional.',
    },
    {
      path: '/schedules',
      label: 'Jadwal',
      permission: 'schedules:view',
      description: 'Kapasitas masuk, booking, dan distribusi pekerjaan harian.',
    },
    {
      path: '/users',
      label: 'User',
      permission: 'users:view',
      description: 'Pengelolaan user internal dan pengaturan role.',
    },
    {
      path: '/reports',
      label: 'Laporan',
      permission: 'reports:view',
      description: 'Analitik performa, SLA, dan produktivitas servis.',
    },
  ],
  mechanic: [
    {
      path: '/mechanic/tasks',
      label: 'Tugas Saya',
      permission: 'mechanic:view-own',
      description: 'Antrean pekerjaan mekanik, tugas prioritas, dan update progres.',
    },
    {
      path: '/services',
      label: 'Board Servis',
      permission: 'services:view',
      description: 'Melihat konteks penuh progres servis saat dibutuhkan.',
    },
  ],
};
