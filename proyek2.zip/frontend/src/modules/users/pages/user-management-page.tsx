import { Card } from '@/common/components/ui/card';

const userRows = [
  { email: 'admin@service.com', role: 'ADMIN', status: 'Aktif' },
  { email: 'manager@service.com', role: 'MANAGER', status: 'Aktif - admin kedua' },
  { email: 'frontline@service.com', role: 'FRONTLINE', status: 'Aktif' },
  { email: 'mechanic@service.com', role: 'MEKANIK', status: 'Aktif' },
];

export function UserManagementPage() {
  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Manajemen User</h1>
        <p className="text-sm text-slate-600">
          Manajer diperlakukan sebagai admin kedua. Karena itu, role MANAGER dan ADMIN sama-sama dapat mengelola user internal.
        </p>
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        {userRows.map((row) => (
          <Card key={row.email}>
            <p className="text-sm font-semibold text-slate-900">{row.email}</p>
            <p className="mt-2 text-sm text-slate-600">Role backend: {row.role}</p>
            <p className="mt-1 text-sm text-slate-500">Status: {row.status}</p>
          </Card>
        ))}
      </div>
    </div>
  );
}
