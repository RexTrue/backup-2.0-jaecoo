import { Card } from '@/common/components/ui/card';

const vehicleTips = [
  'Pencarian cepat berdasarkan plat nomor atau nomor rangka.',
  'Tampilkan kilometer terakhir untuk membantu validasi intake.',
  'Sediakan histori servis untuk admin, manajer, dan frontdesk.',
];

export function VehicleListPage() {
  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Kendaraan</h1>
        <p className="text-sm text-slate-600">Modul yang menyimpan konteks unit, pemilik, kilometer, dan referensi ke work order.</p>
      </div>
      <div className="grid gap-4 lg:grid-cols-3">
        {vehicleTips.map((item) => (
          <Card key={item}>
            <p className="text-sm text-slate-700">{item}</p>
          </Card>
        ))}
      </div>
    </div>
  );
}
