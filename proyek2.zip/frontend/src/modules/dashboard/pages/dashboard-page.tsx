import { Card } from '@/common/components/ui/card';
import { useAuthStore } from '@/modules/auth/store/auth-store';
import { hasPermission, roleLabels } from '@/common/lib/authz';

const summaryMetrics = [
  { label: 'Antrian Aktif', value: '12' },
  { label: 'Sedang Dikerjakan', value: '8' },
  { label: 'Selesai Hari Ini', value: '17' },
  { label: 'Terkendala', value: '3' },
];

const roleHighlights = {
  ADMIN: [
    'Memantau seluruh proses servis, user, dan kualitas data master.',
    'Mengambil alih tindakan frontdesk atau manajer bila diperlukan.',
    'Mengakses laporan dan pengelolaan user tanpa batasan.',
  ],
  MANAGER: [
    'Bertindak sebagai admin kedua dengan akses penuh terhadap modul operasional.',
    'Memantau bottleneck, SLA, jadwal, dan performa mekanik.',
    'Mengelola user dan work order saat admin utama tidak berada di tempat.',
  ],
  FRONTLINE: [
    'Menerima pelanggan, mencari atau membuat data pemilik dan kendaraan.',
    'Membuat work order baru dan memantau progres kendaraan sampai penyerahan.',
    'Menjadi sumber informasi status bagi pelanggan.',
  ],
  MEKANIK: [
    'Melihat daftar tugas pribadi dan memulai pengerjaan servis.',
    'Menambahkan catatan teknis dan memperbarui status progres.',
    'Menandai kendala agar bisa diteruskan ke frontdesk atau manajer.',
  ],
} as const;

const quickActions = [
  { label: 'Buat Work Order Baru', owner: 'FRONTLINE / ADMIN / MANAGER' },
  { label: 'Ubah Assignment Servis', owner: 'ADMIN / MANAGER' },
  { label: 'Lihat Kendaraan Terlambat', owner: 'ADMIN / MANAGER / FRONTLINE' },
  { label: 'Tambah Catatan Mekanik', owner: 'MEKANIK' },
];

export function DashboardPage() {
  const user = useAuthStore((state) => state.user);
  const role = user?.role ?? 'ADMIN';

  return (
    <div className="space-y-6">
      <header className="flex flex-col gap-3 xl:flex-row xl:items-end xl:justify-between">
        <div>
          <p className="text-sm font-medium text-slate-500">Dashboard {roleLabels[role]}</p>
          <h1 className="text-3xl font-bold text-slate-900">Ringkasan operasional servis</h1>
          <p className="mt-2 text-sm text-slate-600">
            Dashboard ini menyesuaikan fokus kerja setiap role, dengan akses manajer disamakan ke level admin operasional.
          </p>
        </div>
        <Card className="min-w-[280px] bg-slate-900 text-white shadow-none">
          <p className="text-xs uppercase tracking-wide text-slate-300">Hak akses aktif</p>
          <p className="mt-2 text-lg font-semibold">
            {hasPermission(role, 'users:view') ? 'Akses penuh operasional' : 'Akses terbatas sesuai tugas'}
          </p>
          <p className="mt-1 text-sm text-slate-300">
            {role === 'MANAGER' ? 'Manajer berperan sebagai admin kedua.' : 'Hak akses ditentukan oleh peran login Anda.'}
          </p>
        </Card>
      </header>

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {summaryMetrics.map((item) => (
          <Card key={item.label}>
            <p className="text-sm text-slate-500">{item.label}</p>
            <p className="mt-2 text-3xl font-bold">{item.value}</p>
          </Card>
        ))}
      </section>

      <section className="grid gap-4 xl:grid-cols-[1.2fr_0.8fr]">
        <Card>
          <h2 className="text-lg font-semibold text-slate-900">Fokus kerja role saat ini</h2>
          <div className="mt-4 space-y-3">
            {roleHighlights[role].map((item) => (
              <div key={item} className="rounded-2xl border border-slate-200 px-4 py-3 text-sm text-slate-700">
                {item}
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <h2 className="text-lg font-semibold text-slate-900">Quick actions yang disarankan</h2>
          <div className="mt-4 space-y-3">
            {quickActions.map((item) => (
              <div key={item.label} className="rounded-2xl bg-slate-50 px-4 py-3">
                <p className="text-sm font-semibold text-slate-900">{item.label}</p>
                <p className="mt-1 text-xs text-slate-500">Pemilik proses: {item.owner}</p>
              </div>
            ))}
          </div>
        </Card>
      </section>
    </div>
  );
}
