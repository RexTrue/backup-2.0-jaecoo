import { Card } from '@/common/components/ui/card';
import { useAuthStore } from '@/modules/auth/store/auth-store';
import { roleLabels } from '@/common/lib/authz';

const reportBuckets = [
  { title: 'SLA Operasional', items: ['Rata-rata durasi servis 4.2 jam', '3 unit overdue', '87% selesai sesuai estimasi'] },
  { title: 'Produktivitas Mekanik', items: ['Mekanik A: 12 servis', 'Mekanik B: 10 servis', '2 kasus terkendala perlu eskalasi'] },
  { title: 'Kapasitas Bengkel', items: ['22 kendaraan masuk minggu ini', '18 work order selesai', '4 unit carry over ke esok hari'] },
];

export function ReportPage() {
  const user = useAuthStore((state) => state.user);

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Laporan Operasional</h1>
        <p className="text-sm text-slate-600">
          Tersedia untuk {roleLabels[user?.role ?? 'ADMIN']}. Manajer memiliki hak akses penuh yang sama dengan admin.
        </p>
      </div>
      <div className="grid gap-4 lg:grid-cols-3">
        {reportBuckets.map((bucket) => (
          <Card key={bucket.title}>
            <h2 className="text-lg font-semibold text-slate-900">{bucket.title}</h2>
            <div className="mt-4 space-y-3">
              {bucket.items.map((item) => (
                <div key={item} className="rounded-2xl bg-slate-50 px-4 py-3 text-sm text-slate-700">
                  {item}
                </div>
              ))}
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
