import { Card } from '@/common/components/ui/card';

const dailyPlan = [
  { slot: '08:00 - 10:00', capacity: '4/5', note: 'Masih ada 1 slot express service.' },
  { slot: '10:00 - 12:00', capacity: '5/5', note: 'Penuh, perlu redistribusi bila ada kendaraan walk-in.' },
  { slot: '13:00 - 15:00', capacity: '3/5', note: 'Ideal untuk booking berkala dan test drive final.' },
];

export function SchedulePage() {
  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Jadwal Servis</h1>
        <p className="text-sm text-slate-600">Pusat kapasitas harian, booking kendaraan masuk, dan kendali distribusi beban kerja.</p>
      </div>
      <div className="grid gap-4 lg:grid-cols-3">
        {dailyPlan.map((item) => (
          <Card key={item.slot}>
            <p className="text-sm text-slate-500">{item.slot}</p>
            <p className="mt-2 text-3xl font-bold text-slate-900">{item.capacity}</p>
            <p className="mt-3 text-sm text-slate-600">{item.note}</p>
          </Card>
        ))}
      </div>
    </div>
  );
}
