import axios from 'axios';
import { apiClient } from '@/services/api-client';
import { LoginPayload, LoginResponse } from '@/modules/auth/types/auth.types';
import { Role, User } from '@/common/types/domain';

const enableDemoAuth = (import.meta.env.VITE_ENABLE_DEMO_AUTH ?? 'true') !== 'false';

type DemoCredential = {
  email: string;
  password: string;
  user: User;
};

const demoUsers: DemoCredential[] = [
  {
    email: 'admin@service.com',
    password: 'Admin123!',
    user: { id_user: 1, email: 'admin@service.com', role: 'ADMIN', isActive: true },
  },
  {
    email: 'frontline@service.com',
    password: 'Frontline123!',
    user: { id_user: 2, email: 'frontline@service.com', role: 'FRONTLINE', isActive: true },
  },
  {
    email: 'manager@service.com',
    password: 'Manager123!',
    user: { id_user: 3, email: 'manager@service.com', role: 'MANAGER', isActive: true },
  },
  {
    email: 'mechanic@service.com',
    password: 'Mechanic123!',
    user: { id_user: 4, email: 'mechanic@service.com', role: 'MEKANIK', isActive: true },
  },
];

function createMockResponse(user: User): LoginResponse {
  return {
    accessToken: `demo-token-${user.role.toLowerCase()}`,
    user,
  };
}

function findDemoUser(payload: LoginPayload): DemoCredential | undefined {
  return demoUsers.find(
    (item) => item.email.toLowerCase() === payload.email.toLowerCase() && item.password === payload.password,
  );
}

function inferRoleFromEmail(email: string): Role {
  const value = email.toLowerCase();
  if (value.includes('mechanic') || value.includes('mekanik')) return 'MEKANIK';
  if (value.includes('frontline') || value.includes('frontdesk')) return 'FRONTLINE';
  if (value.includes('manager') || value.includes('manajer')) return 'MANAGER';
  return 'ADMIN';
}

async function loginWithDemo(payload: LoginPayload): Promise<LoginResponse> {
  const matchedUser = findDemoUser(payload);

  if (!matchedUser) {
    throw new Error(
      'Login demo gagal. Gunakan manager@service.com / Manager123! atau pilih akun demo di halaman login.',
    );
  }

  return createMockResponse(matchedUser.user);
}

async function loginWithBackend(payload: LoginPayload): Promise<LoginResponse> {
  const { data } = await apiClient.post<LoginResponse>('/auth/login', payload);
  return data;
}

export async function login(payload: LoginPayload) {
  if (!enableDemoAuth) {
    return loginWithBackend(payload);
  }

  try {
    return await loginWithBackend(payload);
  } catch (error) {
    if (axios.isAxiosError(error) && !error.response) {
      return loginWithDemo(payload);
    }

    if (axios.isAxiosError(error) && error.response?.status === 404) {
      return loginWithDemo(payload);
    }

    throw error;
  }
}

export const demoCredentials = demoUsers.map(({ email, password, user }) => ({
  email,
  password,
  role: user.role,
}));

export function createQuickDemoSession(email = 'manager@service.com'): LoginResponse {
  const role = inferRoleFromEmail(email);
  const demoUser = demoUsers.find((item) => item.user.role === role) ?? demoUsers[0];
  return createMockResponse({
    ...demoUser.user,
    email,
  });
}
