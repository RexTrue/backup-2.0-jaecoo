import { Card } from '@/common/components/ui/card';

const customerHighlights = [
  'Cari pelanggan berdasarkan NIK, nama, atau nomor HP.',
  'Hubungkan pelanggan ke banyak kendaraan secara aman.',
  'Pastikan frontdesk dapat membuat data baru tanpa menggandakan pelanggan lama.',
];

export function CustomerListPage() {
  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Pelanggan</h1>
        <p className="text-sm text-slate-600">Modul ini selaras dengan entitas Pemilik dan menjadi pintu awal proses frontdesk.</p>
      </div>
      <div className="grid gap-4 lg:grid-cols-3">
        {customerHighlights.map((item) => (
          <Card key={item}>
            <p className="text-sm text-slate-700">{item}</p>
          </Card>
        ))}
      </div>
    </div>
  );
}
