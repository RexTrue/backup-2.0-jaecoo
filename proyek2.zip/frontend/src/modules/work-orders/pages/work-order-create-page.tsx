import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button } from '@/common/components/ui/button';
import { Input } from '@/common/components/ui/input';
import { Card } from '@/common/components/ui/card';

const schema = z.object({
  nik: z.string().min(8, 'NIK minimal 8 karakter'),
  no_rangka: z.string().min(5, 'Nomor rangka minimal 5 karakter'),
  keluhan: z.string().min(5, 'Keluhan minimal 5 karakter'),
});

type FormValues = z.infer<typeof schema>;

export function WorkOrderCreatePage() {
  const { register, handleSubmit } = useForm<FormValues>({ resolver: zodResolver(schema) });

  return (
    <div className="max-w-4xl space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Buat Work Order</h1>
        <p className="text-sm text-slate-600">
          Halaman intake utama untuk frontdesk, namun tetap bisa digunakan admin dan manajer saat mengambil alih operasi.
        </p>
      </div>
      <Card className="bg-slate-900 text-white shadow-none">
        <p className="text-sm font-semibold">Alur yang diharapkan</p>
        <p className="mt-2 text-sm text-slate-200">
          Cari pelanggan, pilih kendaraan, catat keluhan, lalu biarkan backend membuat WorkOrder, Servis awal, dan RiwayatServis pertama.
        </p>
      </Card>
      <form className="space-y-4 rounded-2xl bg-white p-6 shadow-sm" onSubmit={handleSubmit((values) => console.log(values))}>
        <Input placeholder="NIK pelanggan" {...register('nik')} />
        <Input placeholder="Nomor rangka" {...register('no_rangka')} />
        <Input placeholder="Keluhan utama" {...register('keluhan')} />
        <Button type="submit">Simpan Work Order</Button>
      </form>
    </div>
  );
}
