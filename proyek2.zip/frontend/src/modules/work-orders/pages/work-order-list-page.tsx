import { Card } from '@/common/components/ui/card';

const workOrderStates = [
  { label: 'WO Aktif', value: '14', note: 'Masih berjalan di board servis.' },
  { label: 'WO Menunggu Sparepart', value: '2', note: 'Perlu eskalasi ke manajer atau admin.' },
  { label: 'WO Selesai Hari Ini', value: '9', note: 'Siap masuk proses serah terima.' },
];

export function WorkOrderListPage() {
  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Work Order</h1>
        <p className="text-sm text-slate-600">Daftar WO aktif berdasarkan kendaraan yang masuk bengkel dan progres penanganannya.</p>
      </div>
      <div className="grid gap-4 lg:grid-cols-3">
        {workOrderStates.map((item) => (
          <Card key={item.label}>
            <p className="text-sm text-slate-500">{item.label}</p>
            <p className="mt-2 text-3xl font-bold text-slate-900">{item.value}</p>
            <p className="mt-3 text-sm text-slate-600">{item.note}</p>
          </Card>
        ))}
      </div>
    </div>
  );
}
