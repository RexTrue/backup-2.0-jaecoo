import { apiClient } from '@/services/api-client';
import { Service } from '@/common/types/domain';
import { UpdateServiceStatusPayload } from '@/modules/services/types/service.types';

export async function getServices() {
  const { data } = await apiClient.get<Service[]>('/services');
  return data;
}

export async function getServiceDetail(serviceId: string) {
  const { data } = await apiClient.get<Service>(`/services/${serviceId}`);
  return data;
}

export async function updateServiceStatus(serviceId: string, payload: UpdateServiceStatusPayload) {
  const { data } = await apiClient.patch(`/services/${serviceId}/status`, payload);
  return data;
}
