import { ServiceHistory } from '@/common/types/domain';

export function ServiceTimeline({ items }: { items: ServiceHistory[] }) {
  return (
    <ol className="space-y-4">
      {items.map((item) => (
        <li key={item.id_riwayat} className="border-l-2 border-slate-200 pl-4">
          <p className="text-sm font-semibold">{item.status.replace('_', ' ')}</p>
          <p className="text-xs text-slate-500">{new Date(item.waktu).toLocaleString('id-ID')}</p>
        </li>
      ))}
    </ol>
  );
}
