import { Service } from '@/common/types/domain';
import { Card } from '@/common/components/ui/card';
import { StatusBadge } from '@/common/components/data-display/status-badge';

export function ServiceCard({ service }: { service: Service }) {
  return (
    <Card className="space-y-3">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-xs text-slate-500">Servis #{service.id_servis}</p>
          <h3 className="font-semibold">{service.keluhan}</h3>
        </div>
        <StatusBadge status={service.status} />
      </div>
      <p className="text-sm text-slate-600">Prioritas: {service.prioritas}</p>
    </Card>
  );
}
