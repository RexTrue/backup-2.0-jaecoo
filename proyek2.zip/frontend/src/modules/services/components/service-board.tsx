import { Service, ServiceStatus } from '@/common/types/domain';
import { ServiceCard } from '@/modules/services/components/service-card';

const columns: ServiceStatus[] = ['ANTRIAN', 'DIKERJAKAN', 'TEST_DRIVE', 'SELESAI', 'DIAMBIL', 'TERKENDALA'];

export function ServiceBoard({ services }: { services: Service[] }) {
  return (
    <div className="grid gap-4 xl:grid-cols-3 2xl:grid-cols-6">
      {columns.map((status) => (
        <section key={status} className="space-y-3 rounded-2xl bg-slate-100 p-3">
          <header>
            <h2 className="text-sm font-bold">{status.replace('_', ' ')}</h2>
          </header>
          <div className="space-y-3">
            {services.filter((item) => item.status === status).map((service) => (
              <ServiceCard key={service.id_servis} service={service} />
            ))}
          </div>
        </section>
      ))}
    </div>
  );
}
