import { ServiceBoard } from '@/modules/services/components/service-board';
import { Service } from '@/common/types/domain';
import { Card } from '@/common/components/ui/card';

const mockServices: Service[] = [
  {
    id_servis: 1,
    id_wo: 101,
    keluhan: 'Ganti oli, cek rem depan, dan validasi kilometer.',
    status: 'ANTRIAN',
    prioritas: 'NORMAL',
    createdAt: new Date().toISOString(),
  },
  {
    id_servis: 2,
    id_wo: 102,
    keluhan: 'Mesin bergetar saat idle. Butuh inspeksi mounting dan throttle body.',
    status: 'DIKERJAKAN',
    prioritas: 'URGENT',
    createdAt: new Date().toISOString(),
  },
  {
    id_servis: 3,
    id_wo: 103,
    keluhan: 'Test drive akhir setelah service berkala dan balancing.',
    status: 'TEST_DRIVE',
    prioritas: 'HIGH',
    createdAt: new Date().toISOString(),
  },
  {
    id_servis: 4,
    id_wo: 104,
    keluhan: 'Final QC dan penjadwalan penyerahan kendaraan.',
    status: 'SELESAI',
    prioritas: 'NORMAL',
    createdAt: new Date().toISOString(),
  },
  {
    id_servis: 5,
    id_wo: 105,
    keluhan: 'Menunggu sparepart rem belakang, perlu eskalasi ke frontdesk.',
    status: 'TERKENDALA',
    prioritas: 'HIGH',
    createdAt: new Date().toISOString(),
  },
];

export function ServiceBoardPage() {
  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Board Servis</h1>
        <p className="text-sm text-slate-600">Pusat kendali progres servis dari antrian sampai kendaraan diambil.</p>
      </div>
      <Card className="bg-slate-900 text-white shadow-none">
        <p className="text-sm font-semibold">Flow inti operasional</p>
        <p className="mt-2 text-sm text-slate-200">
          Frontdesk membuat work order, mekanik menjalankan pengerjaan, lalu admin atau manajer memantau bottleneck dan kualitas penyelesaian.
        </p>
      </Card>
      <ServiceBoard services={mockServices} />
    </div>
  );
}
