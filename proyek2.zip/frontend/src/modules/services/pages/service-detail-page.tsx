import { Card } from '@/common/components/ui/card';
import { StatusBadge } from '@/common/components/data-display/status-badge';
import { ServiceTimeline } from '@/modules/services/components/service-timeline';
import { useAuthStore } from '@/modules/auth/store/auth-store';
import { hasPermission, roleLabels } from '@/common/lib/authz';

const timeline = [
  { id_riwayat: 1, id_servis: 10, status: 'ANTRIAN' as const, waktu: new Date().toISOString() },
  { id_riwayat: 2, id_servis: 10, status: 'DIKERJAKAN' as const, waktu: new Date().toISOString() },
  { id_riwayat: 3, id_servis: 10, status: 'TEST_DRIVE' as const, waktu: new Date().toISOString() },
];

const actionHints = [
  'ADMIN / MANAGER: assign mekanik, ubah prioritas, dan eskalasi kasus terkendala.',
  'FRONTDESK: update pelanggan, konfirmasi estimasi, dan tandai kendaraan diambil.',
  'MEKANIK: tambah catatan teknis, ubah progres, dan tandai kendala kerja.',
];

export function ServiceDetailPage() {
  const user = useAuthStore((state) => state.user);
  const role = user?.role ?? 'ADMIN';

  return (
    <div className="grid gap-4 xl:grid-cols-[2fr_1fr]">
      <Card>
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-xs text-slate-500">WO #101</p>
            <h1 className="text-2xl font-bold">Servis Kendaraan</h1>
            <p className="mt-2 text-sm text-slate-600">Detail progres servis lintas role untuk memantau status terkini, histori, dan tindakan berikutnya.</p>
          </div>
          <StatusBadge status="DIKERJAKAN" />
        </div>
        <div className="mt-6 grid gap-4 md:grid-cols-2">
          <div>
            <h2 className="font-semibold">Kendaraan</h2>
            <p className="text-sm text-slate-600">Plat: B 1234 XYZ</p>
            <p className="text-sm text-slate-600">No rangka: MH123456789</p>
            <p className="text-sm text-slate-600">Model: Jaecoo J7 AWD</p>
          </div>
          <div>
            <h2 className="font-semibold">Pelanggan</h2>
            <p className="text-sm text-slate-600">Nama: Budi Santoso</p>
            <p className="text-sm text-slate-600">No HP: 08123456789</p>
            <p className="text-sm text-slate-600">Role yang sedang melihat: {roleLabels[role]}</p>
          </div>
        </div>
        <div className="mt-6 rounded-2xl bg-slate-50 p-4">
          <h2 className="font-semibold text-slate-900">Keluhan dan tindakan</h2>
          <p className="mt-2 text-sm text-slate-700">
            Mesin bergetar saat idle. Prioritas tinggi. Estimasi selesai 16:00. Perlu validasi mounting mesin dan road test setelah perbaikan.
          </p>
        </div>
        <div className="mt-6 grid gap-3">
          {actionHints.map((item) => (
            <div key={item} className="rounded-2xl border border-slate-200 px-4 py-3 text-sm text-slate-700">
              {item}
            </div>
          ))}
        </div>
        <div className="mt-6 rounded-2xl bg-slate-900 p-4 text-white">
          <p className="text-sm font-semibold">Hak akses tambahan</p>
          <p className="mt-2 text-sm text-slate-200">
            {hasPermission(role, 'users:view')
              ? 'Anda berada di level admin/manajer, sehingga dapat mengambil alih keputusan operasional penuh.'
              : 'Anda melihat halaman sesuai konteks tugas peran saat ini.'}
          </p>
        </div>
      </Card>
      <Card>
        <h2 className="mb-4 text-lg font-semibold">Timeline</h2>
        <ServiceTimeline items={timeline} />
      </Card>
    </div>
  );
}
