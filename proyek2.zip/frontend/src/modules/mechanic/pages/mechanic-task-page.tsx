import { Card } from '@/common/components/ui/card';
import { StatusBadge } from '@/common/components/data-display/status-badge';

const mechanicTasks = [
  {
    id: '#SRV-102',
    customer: 'Budi Santoso',
    vehicle: 'Jaecoo J7 · B 1234 XYZ',
    issue: 'Mesin bergetar saat idle dan bunyi pada rem depan.',
    status: 'DIKERJAKAN' as const,
    priority: 'URGENT',
  },
  {
    id: '#SRV-104',
    customer: 'Sari Wulandari',
    vehicle: 'Jaecoo J8 · B 9912 KLM',
    issue: 'Cek berkala 10.000 km dan evaluasi test drive.',
    status: 'TEST_DRIVE' as const,
    priority: 'HIGH',
  },
];

export function MechanicTaskPage() {
  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Tugas Saya</h1>
        <p className="text-sm text-slate-600">
          Halaman ringkas untuk mekanik: prioritas pekerjaan, status progres, dan konteks servis yang perlu ditindak.
        </p>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        {mechanicTasks.map((task) => (
          <Card key={task.id} className="space-y-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-xs text-slate-500">{task.id}</p>
                <h2 className="text-lg font-semibold text-slate-900">{task.vehicle}</h2>
                <p className="mt-1 text-sm text-slate-600">Pelanggan: {task.customer}</p>
              </div>
              <StatusBadge status={task.status} />
            </div>
            <p className="text-sm text-slate-700">Keluhan: {task.issue}</p>
            <div className="flex items-center justify-between rounded-2xl bg-slate-50 px-4 py-3 text-sm">
              <span className="font-medium text-slate-700">Prioritas {task.priority}</span>
              <span className="text-slate-500">Aksi: tambah catatan atau lanjutkan progres</span>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
