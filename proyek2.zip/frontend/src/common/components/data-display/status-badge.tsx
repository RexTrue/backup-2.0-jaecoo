import { Badge } from '@/common/components/ui/badge';
import { ServiceStatus } from '@/common/types/domain';

const statusClassMap: Record<ServiceStatus, string> = {
  ANTRIAN: 'bg-slate-100 text-slate-700',
  DIKERJAKAN: 'bg-blue-100 text-blue-700',
  TEST_DRIVE: 'bg-amber-100 text-amber-700',
  SELESAI: 'bg-emerald-100 text-emerald-700',
  DIAMBIL: 'bg-purple-100 text-purple-700',
  TERKENDALA: 'bg-red-100 text-red-700',
};

export function StatusBadge({ status }: { status: ServiceStatus }) {
  return <Badge className={statusClassMap[status]}>{status.replace('_', ' ')}</Badge>;
}
