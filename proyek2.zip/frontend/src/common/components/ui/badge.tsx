import { PropsWithChildren } from 'react';
import { cn } from '@/common/utils/cn';

export function Badge({ children, className }: PropsWithChildren<{ className?: string }>) {
  return <span className={cn('rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-700', className)}>{children}</span>;
}
