import { forwardRef, InputHTMLAttributes } from 'react';
import { cn } from '@/common/utils/cn';

export const Input = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement>>(
  ({ className, ...props }, ref) => (
    <input
      ref={ref}
      className={cn('w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:border-slate-400', className)}
      {...props}
    />
  ),
);

Input.displayName = 'Input';
