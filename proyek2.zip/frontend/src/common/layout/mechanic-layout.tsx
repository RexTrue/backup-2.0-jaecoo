import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { appRoutes } from '@/config/route.config';
import { useAuthStore } from '@/modules/auth/store/auth-store';
import { Button } from '@/common/components/ui/button';
import { roleDescriptions, roleLabels } from '@/common/lib/authz';

export function MechanicLayout() {
  const navigate = useNavigate();
  const user = useAuthStore((state) => state.user);
  const clearSession = useAuthStore((state) => state.clearSession);

  return (
    <div className="min-h-screen bg-slate-50 p-4 md:p-6">
      <header className="rounded-3xl bg-white p-5 shadow-sm">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-xl font-bold text-slate-900">Panel Mekanik</h1>
            <p className="mt-1 text-sm text-slate-600">{user?.email} · {roleLabels[user?.role ?? 'MEKANIK']}</p>
            <p className="mt-2 text-sm text-slate-500">{roleDescriptions[user?.role ?? 'MEKANIK']}</p>
          </div>
          <div className="flex gap-2">
            {appRoutes.mechanic.map((route) => (
              <NavLink
                key={route.path}
                to={route.path}
                className={({ isActive }) =>
                  [
                    'rounded-xl px-4 py-2 text-sm font-medium transition',
                    isActive ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200',
                  ].join(' ')
                }
              >
                {route.label}
              </NavLink>
            ))}
            <Button
              variant="ghost"
              onClick={() => {
                clearSession();
                navigate('/login', { replace: true });
              }}
            >
              Keluar
            </Button>
          </div>
        </div>
      </header>
      <main className="mt-6">
        <Outlet />
      </main>
    </div>
  );
}
