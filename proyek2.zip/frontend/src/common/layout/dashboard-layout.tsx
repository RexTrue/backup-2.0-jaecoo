import { Link, NavLink, Outlet, useNavigate } from 'react-router-dom';
import { appRoutes } from '@/config/route.config';
import { useAuthStore } from '@/modules/auth/store/auth-store';
import { Button } from '@/common/components/ui/button';
import { Card } from '@/common/components/ui/card';
import { hasPermission, roleDescriptions, roleLabels } from '@/common/lib/authz';

export function DashboardLayout() {
  const navigate = useNavigate();
  const user = useAuthStore((state) => state.user);
  const clearSession = useAuthStore((state) => state.clearSession);

  const allowedRoutes = appRoutes.main.filter((route) => hasPermission(user?.role, route.permission));

  return (
    <div className="min-h-screen bg-slate-50 xl:flex">
      <aside className="w-full border-b bg-white p-6 xl:min-h-screen xl:w-80 xl:border-b-0 xl:border-r">
        <Link to="/dashboard" className="block">
          <h1 className="text-xl font-bold text-slate-900">Jaecoo Service Center</h1>
          <p className="mt-1 text-sm text-slate-500">Console operasional servis kendaraan</p>
        </Link>

        <Card className="mt-6 bg-slate-900 text-white shadow-none">
          <p className="text-xs uppercase tracking-wide text-slate-300">Akun aktif</p>
          <p className="mt-2 text-lg font-semibold">{user?.email}</p>
          <p className="mt-1 text-sm text-slate-300">{roleLabels[user?.role ?? 'ADMIN']}</p>
          <p className="mt-3 text-sm text-slate-200">{roleDescriptions[user?.role ?? 'ADMIN']}</p>
        </Card>

        <nav className="mt-6 space-y-2">
          {allowedRoutes.map((route) => (
            <NavLink
              key={route.path}
              to={route.path}
              className={({ isActive }) =>
                [
                  'block rounded-2xl border px-4 py-3 transition',
                  isActive
                    ? 'border-slate-900 bg-slate-900 text-white'
                    : 'border-transparent bg-white text-slate-700 hover:border-slate-200 hover:bg-slate-100',
                ].join(' ')
              }
            >
              <p className="text-sm font-semibold">{route.label}</p>
              <p className="mt-1 text-xs opacity-80">{route.description}</p>
            </NavLink>
          ))}
        </nav>

        <div className="mt-6 flex gap-3">
          <Button variant="secondary" className="flex-1" onClick={() => navigate('/work-orders/new')}>
            WO Baru
          </Button>
          <Button
            variant="ghost"
            className="flex-1"
            onClick={() => {
              clearSession();
              navigate('/login', { replace: true });
            }}
          >
            Keluar
          </Button>
        </div>
      </aside>
      <main className="flex-1 p-4 md:p-6 xl:p-8">
        <Outlet />
      </main>
    </div>
  );
}
