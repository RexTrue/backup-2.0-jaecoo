import { Card } from '@/common/components/ui/card';

const dailyPlan = [
  { slot: '08:00 - 10:00', capacity: '4/5', note: 'Masih ada 1 slot express service.' },
  { slot: '10:00 - 12:00', capacity: '5/5', note: 'Penuh, perlu redistribusi bila ada kendaraan walk-in.' },
  { slot: '13:00 - 15:00', capacity: '3/5', note: 'Ideal untuk booking berkala dan test drive final.' },
];

export function SchedulePage() {
  return (
    <div className="space-y-5">
      <div>
        <p className="text-xs uppercase tracking-[0.28em] text-white/42">Schedules</p>
        <h1 className="section-title mt-3">Kapasitas harian dan distribusi pekerjaan</h1>
        <p className="section-subtitle">Membantu admin dan manajer menjaga beban servis tetap seimbang.</p>
      </div>
      <div className="grid gap-4 lg:grid-cols-3">
        {dailyPlan.map((item) => (
          <Card key={item.slot}>
            <p className="text-sm text-white/55">{item.slot}</p>
            <p className="mt-3 text-4xl font-semibold">{item.capacity}</p>
            <p className="mt-4 text-sm leading-6 text-white/58">{item.note}</p>
          </Card>
        ))}
      </div>
    </div>
  );
}
