import { Link } from 'react-router-dom';
import { Button } from '@/common/components/ui/button';
import { Card } from '@/common/components/ui/card';
import { LandingShell } from '@/modules/landing/components/landing-shell';

const featureCards = [
  {
    title: 'Full role-aware workflow',
    desc: 'Admin, manajer, frontdesk, dan mekanik bekerja pada alur yang terhubung langsung ke board servis dan work order.',
  },
  {
    title: 'Liquid glass dashboard',
    desc: 'Visual premium bergaya Apple Liquid Glass yang tetap rapi, cepat, dan efisien untuk operasional harian.',
  },
  {
    title: 'No self-registration',
    desc: 'Seluruh akun diatur admin internal sehingga kontrol akses lebih enterprise, aman, dan konsisten.',
  },
];

const flowSteps = [
  'Frontdesk menerima pelanggan dan membuat work order.',
  'Mekanik memperbarui progres, catatan teknis, dan status pengerjaan.',
  'Manajer bertindak sebagai admin kedua untuk monitoring penuh.',
  'Admin menjaga kualitas data, user, dan keseluruhan operasional.',
];

export function LandingPage() {
  return (
    <div className="pb-16">
      <LandingShell>
        <header className="sticky top-0 z-40 mt-4 rounded-[28px] border border-white/10 bg-[#081019]/68 px-4 py-3 backdrop-blur-xl md:px-6">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <img src="/assets/logo-jaecoo-white.png" alt="JAECOO" className="h-7 w-auto" />
              <div>
                <p className="text-xs uppercase tracking-[0.28em] text-white/42">JAECOO Yogyakarta</p>
                <p className="text-sm font-medium text-white/88">Service Management System</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <a href="#features" className="hidden text-sm text-white/65 hover:text-white md:block">Fitur</a>
              <a href="#flow" className="hidden text-sm text-white/65 hover:text-white md:block">Flow</a>
              <Link to="/login"><Button>Masuk Sistem</Button></Link>
            </div>
          </div>
        </header>

        <section className="grid gap-8 pt-8 lg:grid-cols-[1.05fr_0.95fr] lg:items-center lg:pt-14">
          <div className="animate-fade-up">
            <div className="inline-flex rounded-full border border-[#d9be89]/20 bg-[#d9be89]/10 px-4 py-2 text-xs uppercase tracking-[0.28em] text-[#f1d9aa]">
              Premium internal operations platform
            </div>
            <h1 className="mt-6 max-w-4xl text-4xl font-semibold leading-tight text-white md:text-6xl">
              Satu sistem modern untuk mengelola servis JAECOO dengan tampilan <span className="text-gradient">premium dan efisien</span>.
            </h1>
            <p className="mt-5 max-w-2xl text-base leading-8 text-white/65 md:text-lg">
              Dirancang untuk cepat dibuka di desktop, laptop, tablet, dan ponsel. Estetik, rapi, dan tegas untuk aktivitas frontdesk,
              manajer, admin, hingga mekanik.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/login"><Button className="min-w-[180px]">Masuk ke Dashboard</Button></Link>
              <a href="#preview"><Button variant="secondary" className="min-w-[180px]">Lihat Preview</Button></a>
            </div>
          </div>

          <div className="relative animate-float-slow">
            <div className="absolute -inset-4 rounded-[34px] bg-[radial-gradient(circle_at_top,rgba(197,167,109,0.28),transparent_32%)] blur-3xl" />
            <Card className="relative overflow-hidden rounded-[34px] p-3">
              <img src="/assets/img1.jpg" alt="JAECOO product" className="h-[520px] w-full rounded-[28px] object-cover" />
              <div className="absolute inset-x-5 bottom-5 glass rounded-[26px] p-5">
                <p className="text-xs uppercase tracking-[0.28em] text-white/45">Automotive elegance</p>
                <p className="mt-2 text-2xl font-semibold text-white">JAECOO Yogyakarta Service Experience</p>
                <p className="mt-2 max-w-lg text-sm leading-6 text-white/62">Landing page bernuansa mewah dengan visual produk JAECOO, transisi halus, dan branding kuat.</p>
              </div>
            </Card>
          </div>
        </section>

        <section id="features" className="pt-20">
          <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
            <div>
              <p className="text-xs uppercase tracking-[0.28em] text-white/40">Core highlights</p>
              <h2 className="section-title">Fitur yang mendukung operasional dan estetika</h2>
            </div>
            <p className="max-w-2xl text-sm leading-7 text-white/55">
              Dibangun untuk tampil elegan tanpa mengorbankan kecepatan akses, keterbacaan, atau alur kerja harian bengkel.
            </p>
          </div>
          <div className="mt-6 grid gap-4 lg:grid-cols-3">
            {featureCards.map((card) => (
              <Card key={card.title} className="min-h-[220px]">
                <p className="text-xs uppercase tracking-[0.24em] text-[#f1d9aa]/80">JAECOO Standard</p>
                <h3 className="mt-5 text-2xl font-semibold">{card.title}</h3>
                <p className="mt-4 text-sm leading-7 text-white/62">{card.desc}</p>
              </Card>
            ))}
          </div>
        </section>

        <section id="preview" className="grid gap-6 pt-20 lg:grid-cols-[0.8fr_1.2fr] lg:items-center">
          <Card className="overflow-hidden p-0">
            <div className="grid gap-0 md:grid-cols-2">
              <img src="/assets/img3.webp" alt="JAECOO preview" className="h-full min-h-[340px] w-full object-cover" />
              <div className="p-6 md:p-8">
                <p className="text-xs uppercase tracking-[0.26em] text-white/45">Responsive experience</p>
                <h3 className="mt-4 text-3xl font-semibold">Cepat diakses, indah dilihat, nyaman dipakai.</h3>
                <p className="mt-4 text-sm leading-7 text-white/62">
                  Sidebar kiri yang adaptif, hamburger menu di mobile, board servis yang fleksibel, serta komponen kaca profesional untuk seluruh perangkat.
                </p>
              </div>
            </div>
          </Card>
          <div className="grid gap-4 sm:grid-cols-2">
            {['Dashboard KPI', 'Board Servis', 'Work Order Intake', 'Manajemen User'].map((label, index) => (
              <Card key={label} className="min-h-[180px]">
                <p className="text-xs uppercase tracking-[0.28em] text-white/42">0{index + 1}</p>
                <h3 className="mt-4 text-xl font-semibold">{label}</h3>
                <p className="mt-3 text-sm leading-7 text-white/60">Komponen dirancang ringkas dengan transisi elegan, panel transparan, dan readability tetap tinggi.</p>
              </Card>
            ))}
          </div>
        </section>

        <section id="flow" className="pt-20">
          <Card className="overflow-hidden">
            <div className="grid gap-8 lg:grid-cols-[0.9fr_1.1fr] lg:items-start">
              <div>
                <p className="text-xs uppercase tracking-[0.28em] text-white/42">Service flow</p>
                <h2 className="mt-4 text-3xl font-semibold">Alur kerja yang selaras dengan backend dan database.</h2>
                <p className="mt-4 text-sm leading-7 text-white/62">
                  Setiap laman dan role mengikuti alur intake kendaraan, pengerjaan, monitoring, hingga serah terima akhir dengan jalur yang mudah dipahami.
                </p>
              </div>
              <div className="space-y-4">
                {flowSteps.map((step, index) => (
                  <div key={step} className="glass-soft rounded-[24px] p-4">
                    <p className="text-xs uppercase tracking-[0.24em] text-[#f1d9aa]/80">Step {index + 1}</p>
                    <p className="mt-2 text-sm leading-7 text-white/74">{step}</p>
                  </div>
                ))}
              </div>
            </div>
          </Card>
        </section>
      </LandingShell>
    </div>
  );
}
