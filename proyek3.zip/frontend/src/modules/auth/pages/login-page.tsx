import { useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button } from '@/common/components/ui/button';
import { Input } from '@/common/components/ui/input';
import { Card } from '@/common/components/ui/card';
import { useLogin, getErrorMessage } from '@/modules/auth/hooks/use-login';
import { createQuickDemoSession, demoCredentials } from '@/modules/auth/services/auth-api';
import { useAuthStore } from '@/modules/auth/store/auth-store';
import { getDefaultRouteByRole, roleDescriptions, roleLabels } from '@/common/lib/authz';

const schema = z.object({
  email: z.string().email('Email tidak valid'),
  password: z.string().min(6, 'Password minimal 6 karakter'),
});

type FormValues = z.infer<typeof schema>;

export function LoginPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const user = useAuthStore((state) => state.user);
  const setSession = useAuthStore((state) => state.setSession);
  const loginMutation = useLogin();
  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { email: 'manager@service.com', password: 'Manager123!' },
  });

  useEffect(() => {
    if (loginMutation.isSuccess && user) {
      const targetPath = (location.state as { from?: { pathname?: string } } | undefined)?.from?.pathname;
      navigate(targetPath ?? getDefaultRouteByRole(user.role), { replace: true });
    }
  }, [location.state, loginMutation.isSuccess, navigate, user]);

  const errorMessage = loginMutation.isError ? getErrorMessage(loginMutation.error) : null;

  return (
    <div className="animate-fade-up">
      <div className="mb-6 lg:hidden">
        <img src="/assets/logo-jaecoo-white.png" alt="JAECOO" className="h-7 w-auto" />
        <p className="mt-4 text-2xl font-semibold text-white">Masuk ke JAECOO Yogyakarta Service Management System</p>
      </div>

      <Card className="rounded-[30px] p-6 md:p-8">
        <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
          <div>
            <p className="text-xs uppercase tracking-[0.28em] text-white/45">Internal access only</p>
            <h1 className="mt-3 text-3xl font-semibold text-white">Masuk ke sistem</h1>
            <p className="mt-2 text-sm leading-7 text-white/62">
              Tidak ada register. Seluruh akun dikelola admin internal. Manajer memiliki akses penuh sebagai admin kedua.
            </p>
          </div>
          <Button
            type="button"
            variant="secondary"
            onClick={() => {
              const quickSession = createQuickDemoSession('manager@service.com');
              setSession({ token: quickSession.accessToken, user: quickSession.user });
              navigate(getDefaultRouteByRole(quickSession.user.role), { replace: true });
            }}
          >
            Demo Manajer
          </Button>
        </div>

        <form className="mt-6 space-y-4" onSubmit={handleSubmit((values) => loginMutation.mutate(values))}>
          <div>
            <label className="mb-2 block text-xs uppercase tracking-[0.24em] text-white/45">Email</label>
            <Input placeholder="manager@service.com" {...register('email')} />
            {errors.email && <p className="mt-2 text-xs text-red-300">{errors.email.message}</p>}
          </div>
          <div>
            <label className="mb-2 block text-xs uppercase tracking-[0.24em] text-white/45">Password</label>
            <Input type="password" placeholder="••••••••" {...register('password')} />
            {errors.password && <p className="mt-2 text-xs text-red-300">{errors.password.message}</p>}
          </div>
          {errorMessage && <p className="rounded-2xl border border-red-300/20 bg-red-400/10 px-4 py-3 text-sm text-red-100">{errorMessage}</p>}
          <Button type="submit" className="w-full" disabled={loginMutation.isPending}>
            {loginMutation.isPending ? 'Memproses...' : 'Masuk ke dashboard'}
          </Button>
        </form>

        <div className="mt-7 rounded-[24px] border border-white/8 bg-white/6 p-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="text-sm font-semibold text-white">Akun demo siap pakai</h2>
              <p className="mt-1 text-xs text-white/55">Untuk uji role dan alur UI. Nantinya akun riil dikelola dari panel admin.</p>
            </div>
            <div className="rounded-full border border-white/10 bg-white/6 px-3 py-1 text-xs text-white/55">No register</div>
          </div>

          <div className="mt-4 grid gap-3">
            {demoCredentials.map((credential) => (
              <div key={credential.email} className="rounded-[22px] border border-white/8 bg-black/10 p-4">
                <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                  <div>
                    <p className="text-sm font-medium text-white">{roleLabels[credential.role]}</p>
                    <p className="mt-1 text-xs text-white/62">{credential.email}</p>
                    <p className="text-xs text-white/62">{credential.password}</p>
                    <p className="mt-2 text-xs text-white/48">{roleDescriptions[credential.role]}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      type="button"
                      variant="secondary"
                      onClick={() => {
                        setValue('email', credential.email, { shouldValidate: true });
                        setValue('password', credential.password, { shouldValidate: true });
                      }}
                    >
                      Isi
                    </Button>
                    <Button
                      type="button"
                      onClick={() => {
                        const quickSession = createQuickDemoSession(credential.email);
                        setSession({ token: quickSession.accessToken, user: quickSession.user });
                        navigate(getDefaultRouteByRole(quickSession.user.role), { replace: true });
                      }}
                    >
                      Masuk
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </Card>
    </div>
  );
}
