import { Card } from '@/common/components/ui/card';
import { useAuthStore } from '@/modules/auth/store/auth-store';
import { hasPermission, roleLabels } from '@/common/lib/authz';

const summaryMetrics = [
  { label: 'Antrian Aktif', value: '12', helper: 'Unit menunggu intake atau assignment.' },
  { label: 'Sedang Dikerjakan', value: '08', helper: 'Pekerjaan aktif lintas stall bengkel.' },
  { label: 'Selesai Hari Ini', value: '17', helper: 'Siap diserahkan ke pelanggan.' },
  { label: 'Terkendala', value: '03', helper: 'Perlu approval atau sparepart.' },
];

const priorities = [
  { title: 'Frontdesk lane', detail: 'Cari pelanggan, pilih kendaraan, buat work order, dan konfirmasi estimasi selesai.' },
  { title: 'Manager control', detail: 'Memantau bottleneck, SLA, dan assignment. Berperan sebagai admin kedua.' },
  { title: 'Mechanic execution', detail: 'Mulai kerja, tambahkan catatan, uji test drive, dan tandai selesai.' },
];

export function DashboardPage() {
  const user = useAuthStore((state) => state.user);
  const role = user?.role ?? 'ADMIN';

  return (
    <div className="space-y-6">
      <section className="grid gap-5 xl:grid-cols-[1.2fr_0.8fr]">
        <Card className="overflow-hidden">
          <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <p className="text-xs uppercase tracking-[0.28em] text-white/45">Operational cockpit</p>
              <h1 className="section-title mt-4">Dashboard {roleLabels[role]}</h1>
              <p className="section-subtitle max-w-3xl">
                Tampilan ringkas untuk memantau intake kendaraan, progres servis, kualitas penyelesaian, dan kontrol akses harian.
              </p>
            </div>
            <div className="rounded-[24px] border border-white/10 bg-white/6 px-5 py-4 text-sm text-white/70">
              {hasPermission(role, 'users:view')
                ? 'Anda berada pada level akses penuh operasional.'
                : 'Tampilan difokuskan pada tugas lapangan sesuai role aktif.'}
            </div>
          </div>
        </Card>

        <Card className="overflow-hidden p-0">
          <img src="/assets/img2.webp" alt="JAECOO dashboard" className="h-full min-h-[260px] w-full object-cover" />
        </Card>
      </section>

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {summaryMetrics.map((item) => (
          <Card key={item.label}>
            <p className="text-sm text-white/55">{item.label}</p>
            <p className="mt-3 text-4xl font-semibold tracking-tight">{item.value}</p>
            <p className="mt-4 text-sm leading-6 text-white/58">{item.helper}</p>
          </Card>
        ))}
      </section>

      <section className="grid gap-4 xl:grid-cols-[1fr_1fr]">
        <Card>
          <p className="text-xs uppercase tracking-[0.28em] text-white/42">Workflow focus</p>
          <div className="mt-4 space-y-3">
            {priorities.map((item) => (
              <div key={item.title} className="rounded-[22px] border border-white/8 bg-white/6 p-4">
                <p className="text-sm font-semibold text-white">{item.title}</p>
                <p className="mt-2 text-sm leading-7 text-white/60">{item.detail}</p>
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <p className="text-xs uppercase tracking-[0.28em] text-white/42">Quick glance</p>
          <div className="mt-4 grid gap-3 md:grid-cols-2">
            {[
              'Service board menampilkan status ANTRIAN hingga DIAMBIL.',
              'Sidebar tetap di kiri dan berubah menjadi overlay di mobile.',
              'Tidak ada register. Admin membuat dan mengelola akun.',
              'Manager memegang kuasa penuh setara admin operasional.',
            ].map((item) => (
              <div key={item} className="rounded-[22px] border border-white/8 bg-black/10 p-4 text-sm leading-7 text-white/64">
                {item}
              </div>
            ))}
          </div>
        </Card>
      </section>
    </div>
  );
}
