import { Card } from '@/common/components/ui/card';
import { useAuthStore } from '@/modules/auth/store/auth-store';
import { roleLabels } from '@/common/lib/authz';

const reportBuckets = [
  { title: 'SLA Operasional', items: ['Rata-rata durasi servis 4,2 jam', '3 unit overdue', '87% selesai sesuai estimasi'] },
  { title: 'Produktivitas Mekanik', items: ['Mekanik A: 12 servis', 'Mekanik B: 10 servis', '2 kasus terkendala perlu eskalasi'] },
  { title: 'Kapasitas Bengkel', items: ['22 kendaraan masuk minggu ini', '18 work order selesai', '4 unit carry over ke esok hari'] },
];

export function ReportPage() {
  const user = useAuthStore((state) => state.user);

  return (
    <div className="space-y-5">
      <div>
        <p className="text-xs uppercase tracking-[0.28em] text-white/42">Reports</p>
        <h1 className="section-title mt-3">Laporan performa dan kualitas operasional</h1>
        <p className="section-subtitle">Tersedia untuk {roleLabels[user?.role ?? 'ADMIN']} dan cocok dibaca cepat di perangkat besar maupun mobile.</p>
      </div>
      <div className="grid gap-4 xl:grid-cols-3">
        {reportBuckets.map((bucket) => (
          <Card key={bucket.title}>
            <h2 className="text-xl font-semibold text-white">{bucket.title}</h2>
            <div className="mt-4 space-y-3">
              {bucket.items.map((item) => (
                <div key={item} className="rounded-[20px] border border-white/8 bg-white/6 px-4 py-3 text-sm leading-7 text-white/64">{item}</div>
              ))}
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
