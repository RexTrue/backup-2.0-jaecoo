import { Card } from '@/common/components/ui/card';

const workOrderStates = [
  { label: 'WO Aktif', value: '14', note: 'Masih berjalan di board servis.' },
  { label: 'Menunggu Sparepart', value: '2', note: 'Butuh eskalasi cepat ke manajer atau admin.' },
  { label: 'Selesai Hari Ini', value: '9', note: 'Siap untuk serah terima pelanggan.' },
];

export function WorkOrderListPage() {
  return (
    <div className="space-y-5">
      <div>
        <p className="text-xs uppercase tracking-[0.28em] text-white/42">Work orders</p>
        <h1 className="section-title mt-3">Pusat intake dan monitoring dokumen servis</h1>
        <p className="section-subtitle">Frontdesk, admin, dan manajer dapat melihat seluruh work order aktif dengan ringkas.</p>
      </div>
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {workOrderStates.map((item) => (
          <Card key={item.label}>
            <p className="text-sm text-white/55">{item.label}</p>
            <p className="mt-3 text-4xl font-semibold">{item.value}</p>
            <p className="mt-4 text-sm leading-6 text-white/58">{item.note}</p>
          </Card>
        ))}
      </div>
    </div>
  );
}
