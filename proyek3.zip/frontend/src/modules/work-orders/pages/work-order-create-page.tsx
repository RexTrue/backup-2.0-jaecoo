import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button } from '@/common/components/ui/button';
import { Input } from '@/common/components/ui/input';
import { Card } from '@/common/components/ui/card';

const schema = z.object({
  nik: z.string().min(8, 'NIK minimal 8 karakter'),
  no_rangka: z.string().min(5, 'Nomor rangka minimal 5 karakter'),
  keluhan: z.string().min(5, 'Keluhan minimal 5 karakter'),
});

type FormValues = z.infer<typeof schema>;

export function WorkOrderCreatePage() {
  const { register, handleSubmit, formState: { errors } } = useForm<FormValues>({ resolver: zodResolver(schema) });

  return (
    <div className="grid gap-5 xl:grid-cols-[0.72fr_1.28fr]">
      <Card>
        <p className="text-xs uppercase tracking-[0.28em] text-white/42">Intake guide</p>
        <h1 className="mt-4 text-3xl font-semibold">Buat work order baru</h1>
        <p className="mt-4 text-sm leading-7 text-white/62">
          Halaman ini dirancang untuk frontdesk, tetapi tetap aman dipakai admin dan manajer saat mengambil alih operasional. Setelah submit,
          backend akan menyiapkan work order, servis awal, dan riwayat pertama.
        </p>
      </Card>

      <Card>
        <form className="grid gap-4" onSubmit={handleSubmit((values) => console.log(values))}>
          <div>
            <label className="mb-2 block text-xs uppercase tracking-[0.24em] text-white/45">NIK pelanggan</label>
            <Input placeholder="3401123456780001" {...register('nik')} />
            {errors.nik && <p className="mt-2 text-xs text-red-300">{errors.nik.message}</p>}
          </div>
          <div>
            <label className="mb-2 block text-xs uppercase tracking-[0.24em] text-white/45">Nomor rangka</label>
            <Input placeholder="MHCJAECOOJ7YOGYA01" {...register('no_rangka')} />
            {errors.no_rangka && <p className="mt-2 text-xs text-red-300">{errors.no_rangka.message}</p>}
          </div>
          <div>
            <label className="mb-2 block text-xs uppercase tracking-[0.24em] text-white/45">Keluhan utama</label>
            <Input placeholder="Mesin bergetar saat idle dan rem depan berbunyi" {...register('keluhan')} />
            {errors.keluhan && <p className="mt-2 text-xs text-red-300">{errors.keluhan.message}</p>}
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="rounded-[22px] border border-white/8 bg-white/6 p-4 text-sm text-white/58">Validasi pelanggan dan kendaraan sebelum submit.</div>
            <div className="rounded-[22px] border border-white/8 bg-white/6 p-4 text-sm text-white/58">Estimasi dan prioritas dapat diatur sesudah intake selesai.</div>
          </div>
          <Button type="submit" className="mt-2">Simpan work order</Button>
        </form>
      </Card>
    </div>
  );
}
