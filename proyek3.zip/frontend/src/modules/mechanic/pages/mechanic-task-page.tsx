import { Card } from '@/common/components/ui/card';
import { StatusBadge } from '@/common/components/data-display/status-badge';
import { Button } from '@/common/components/ui/button';

const mechanicTasks = [
  { id: '#SRV-102', customer: 'Budi Santoso', vehicle: 'JAECOO J7 · AB 1234 JQ', issue: 'Mesin bergetar saat idle dan bunyi pada rem depan.', status: 'DIKERJAKAN' as const, priority: 'URGENT' },
  { id: '#SRV-104', customer: 'Sari Wulandari', vehicle: 'JAECOO J8 · AB 9912 OO', issue: 'Cek berkala 10.000 km dan evaluasi test drive.', status: 'TEST_DRIVE' as const, priority: 'HIGH' },
];

export function MechanicTaskPage() {
  return (
    <div className="space-y-5">
      <div>
        <p className="text-xs uppercase tracking-[0.28em] text-white/42">My tasks</p>
        <h1 className="section-title mt-3">Panel tugas mekanik</h1>
        <p className="section-subtitle">Lebih sederhana, tombol lebih besar, dan nyaman dipakai via tablet atau ponsel saat di area workshop.</p>
      </div>
      <div className="grid gap-4 xl:grid-cols-2">
        {mechanicTasks.map((task) => (
          <Card key={task.id} className="space-y-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-[11px] uppercase tracking-[0.24em] text-white/42">{task.id}</p>
                <h2 className="mt-2 text-xl font-semibold text-white">{task.vehicle}</h2>
                <p className="mt-1 text-sm text-white/60">Pelanggan: {task.customer}</p>
              </div>
              <StatusBadge status={task.status} />
            </div>
            <p className="text-sm leading-7 text-white/68">Keluhan: {task.issue}</p>
            <div className="rounded-[22px] border border-white/8 bg-white/6 px-4 py-3 text-sm text-white/64">Prioritas {task.priority}</div>
            <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
              <Button variant="secondary">Mulai</Button>
              <Button variant="secondary">Catatan</Button>
              <Button variant="secondary">Test Drive</Button>
              <Button>Finish</Button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
