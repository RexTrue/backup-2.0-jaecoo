import { Card } from '@/common/components/ui/card';
import { Button } from '@/common/components/ui/button';

const userRows = [
  { email: 'admin@service.com', role: 'ADMIN', status: 'Aktif' },
  { email: 'manager@service.com', role: 'MANAGER', status: 'Aktif - admin kedua' },
  { email: 'frontline@service.com', role: 'FRONTLINE', status: 'Aktif' },
  { email: 'mechanic@service.com', role: 'MEKANIK', status: 'Aktif' },
];

export function UserManagementPage() {
  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="text-xs uppercase tracking-[0.28em] text-white/42">Users</p>
          <h1 className="section-title mt-3">Manajemen akun internal</h1>
          <p className="section-subtitle">Tidak ada register. Admin dan manajer mengelola seluruh akun dari panel ini.</p>
        </div>
        <Button>Tambah user</Button>
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        {userRows.map((row) => (
          <Card key={row.email}>
            <p className="text-sm font-semibold text-white">{row.email}</p>
            <p className="mt-3 text-sm text-white/62">Role backend: {row.role}</p>
            <p className="mt-1 text-sm text-white/52">Status: {row.status}</p>
          </Card>
        ))}
      </div>
    </div>
  );
}
