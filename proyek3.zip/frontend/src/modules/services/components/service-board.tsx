import { Service, ServiceStatus } from '@/common/types/domain';
import { ServiceCard } from '@/modules/services/components/service-card';

const columns: ServiceStatus[] = ['ANTRIAN', 'DIKERJAKAN', 'TEST_DRIVE', 'SELESAI', 'DIAMBIL', 'TERKENDALA'];

export function ServiceBoard({ services }: { services: Service[] }) {
  return (
    <div className="-mx-4 overflow-x-auto px-4 pb-2">
      <div className="grid min-w-[1180px] gap-4 xl:min-w-0 xl:grid-cols-3 2xl:grid-cols-6">
        {columns.map((status) => (
          <section key={status} className="glass-soft rounded-[28px] p-3">
            <header className="mb-3 flex items-center justify-between rounded-[20px] border border-white/8 bg-black/10 px-4 py-3">
              <h2 className="text-sm font-semibold text-white">{status.replace('_', ' ')}</h2>
              <span className="rounded-full border border-white/8 bg-white/8 px-2.5 py-1 text-xs text-white/58">
                {services.filter((item) => item.status === status).length}
              </span>
            </header>
            <div className="space-y-3">
              {services.filter((item) => item.status === status).map((service) => (
                <ServiceCard key={service.id_servis} service={service} />
              ))}
            </div>
          </section>
        ))}
      </div>
    </div>
  );
}
