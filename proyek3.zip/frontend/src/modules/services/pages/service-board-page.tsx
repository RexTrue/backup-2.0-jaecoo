import { ServiceBoard } from '@/modules/services/components/service-board';
import { Service } from '@/common/types/domain';
import { Card } from '@/common/components/ui/card';

const mockServices: Service[] = [
  { id_servis: 1, id_wo: 101, keluhan: 'Ganti oli, cek rem depan, dan validasi kilometer.', status: 'ANTRIAN', prioritas: 'NORMAL', createdAt: new Date().toISOString() },
  { id_servis: 2, id_wo: 102, keluhan: 'Mesin bergetar saat idle. Butuh inspeksi mounting dan throttle body.', status: 'DIKERJAKAN', prioritas: 'URGENT', createdAt: new Date().toISOString() },
  { id_servis: 3, id_wo: 103, keluhan: 'Test drive akhir setelah service berkala dan balancing.', status: 'TEST_DRIVE', prioritas: 'HIGH', createdAt: new Date().toISOString() },
  { id_servis: 4, id_wo: 104, keluhan: 'Final QC dan penjadwalan penyerahan kendaraan.', status: 'SELESAI', prioritas: 'NORMAL', createdAt: new Date().toISOString() },
  { id_servis: 5, id_wo: 105, keluhan: 'Menunggu sparepart rem belakang, perlu eskalasi ke frontdesk.', status: 'TERKENDALA', prioritas: 'HIGH', createdAt: new Date().toISOString() },
  { id_servis: 6, id_wo: 106, keluhan: 'Kendaraan siap diambil pelanggan setelah final wash.', status: 'DIAMBIL', prioritas: 'NORMAL', createdAt: new Date().toISOString() },
];

export function ServiceBoardPage() {
  return (
    <div className="space-y-5">
      <div>
        <p className="text-xs uppercase tracking-[0.28em] text-white/42">Service board</p>
        <h1 className="section-title mt-3">Pusat kendali progres servis dari intake hingga serah terima</h1>
        <p className="section-subtitle">Board horizontal di mobile dan grid penuh di desktop agar tetap enak dipakai di semua perangkat.</p>
      </div>
      <Card>
        <p className="text-sm leading-7 text-white/62">
          Frontdesk membuat work order, mekanik mengerjakan unit, dan admin serta manajer mengawasi kualitas serta bottleneck secara real-time.
        </p>
      </Card>
      <ServiceBoard services={mockServices} />
    </div>
  );
}
