import { Card } from '@/common/components/ui/card';
import { StatusBadge } from '@/common/components/data-display/status-badge';
import { ServiceTimeline } from '@/modules/services/components/service-timeline';
import { useAuthStore } from '@/modules/auth/store/auth-store';
import { hasPermission, roleLabels } from '@/common/lib/authz';

const timeline = [
  { id_riwayat: 1, id_servis: 10, status: 'ANTRIAN' as const, waktu: new Date().toISOString() },
  { id_riwayat: 2, id_servis: 10, status: 'DIKERJAKAN' as const, waktu: new Date().toISOString() },
  { id_riwayat: 3, id_servis: 10, status: 'TEST_DRIVE' as const, waktu: new Date().toISOString() },
];

export function ServiceDetailPage() {
  const user = useAuthStore((state) => state.user);
  const role = user?.role ?? 'ADMIN';

  return (
    <div className="grid gap-5 xl:grid-cols-[1.4fr_0.8fr]">
      <Card>
        <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
          <div>
            <p className="text-xs uppercase tracking-[0.28em] text-white/42">WO #101</p>
            <h1 className="mt-3 text-3xl font-semibold">Servis kendaraan JAECOO J7</h1>
            <p className="mt-3 text-sm leading-7 text-white/62">Detail progres servis lintas role untuk memantau status, histori, dan tindakan berikutnya.</p>
          </div>
          <StatusBadge status="DIKERJAKAN" />
        </div>

        <div className="mt-6 grid gap-4 md:grid-cols-2">
          <div className="rounded-[24px] border border-white/8 bg-white/6 p-5">
            <h2 className="text-sm font-semibold uppercase tracking-[0.24em] text-white/46">Kendaraan</h2>
            <div className="mt-3 space-y-2 text-sm text-white/66">
              <p>Plat: AB 1234 JQ</p>
              <p>No rangka: MHCJAECOOJ7YOGYA01</p>
              <p>Model: JAECOO J7 AWD</p>
              <p>Kilometer: 12.420 km</p>
            </div>
          </div>
          <div className="rounded-[24px] border border-white/8 bg-white/6 p-5">
            <h2 className="text-sm font-semibold uppercase tracking-[0.24em] text-white/46">Pelanggan</h2>
            <div className="mt-3 space-y-2 text-sm text-white/66">
              <p>Nama: Budi Santoso</p>
              <p>No HP: 0812-3456-7890</p>
              <p>Viewer: {roleLabels[role]}</p>
              <p>Estimasi selesai: 16.00 WIB</p>
            </div>
          </div>
        </div>

        <div className="mt-6 rounded-[24px] border border-white/8 bg-black/10 p-5">
          <h2 className="text-sm font-semibold uppercase tracking-[0.24em] text-white/46">Keluhan dan tindakan</h2>
          <p className="mt-3 text-sm leading-7 text-white/68">
            Mesin bergetar saat idle. Prioritas tinggi. Perlu validasi mounting mesin, cek throttle body, lalu road test setelah perbaikan.
          </p>
        </div>

        <div className="mt-6 grid gap-3 md:grid-cols-3">
          {[
            'Admin / Manajer dapat mengubah prioritas, assignment, dan eskalasi.',
            'Frontdesk mengonfirmasi pelanggan dan status akhir penyerahan.',
            'Mekanik memperbarui progres, catatan teknis, dan test drive.',
          ].map((item) => (
            <div key={item} className="rounded-[22px] border border-white/8 bg-white/6 p-4 text-sm leading-7 text-white/62">{item}</div>
          ))}
        </div>

        <div className="mt-6 rounded-[24px] border border-[#d9be89]/20 bg-[#d9be89]/10 p-5 text-sm leading-7 text-white/78">
          {hasPermission(role, 'users:view')
            ? 'Anda berada di level admin/manajer sehingga memiliki kuasa penuh operasional, termasuk user management dan penyesuaian workflow.'
            : 'Anda melihat halaman sesuai konteks pekerjaan pada role aktif.'}
        </div>
      </Card>

      <Card>
        <h2 className="text-xl font-semibold">Timeline status</h2>
        <p className="mt-2 text-sm text-white/55">Riwayat perubahan status penting untuk audit progres dan komunikasi lintas role.</p>
        <div className="mt-6">
          <ServiceTimeline items={timeline} />
        </div>
      </Card>
    </div>
  );
}
