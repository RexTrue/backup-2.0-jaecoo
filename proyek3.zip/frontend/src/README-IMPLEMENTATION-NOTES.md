JAECOO Yogyakarta Service Management System

Perubahan frontend yang diimplementasikan:
- Landing page premium dengan visual produk JAECOO dari /public/assets
- Login tanpa register dengan demo auth dan pesan bahwa akun dikelola admin
- Sidebar kiri responsif dengan hamburger overlay di tablet/mobile
- Tema Liquid Glass profesional dengan palet dark premium + gold accent
- Manager diperlakukan sebagai admin kedua di UI dan permission layer
- Laman utama ditata ulang agar lebih estetik, ringkas, dan responsive
