import { Outlet } from 'react-router-dom';

export function AuthLayout() {
  return (
    <div className="relative min-h-screen overflow-hidden px-4 py-6 md:px-6 lg:px-8">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(197,167,109,0.22),transparent_20%),radial-gradient(circle_at_bottom_left,rgba(130,161,255,0.15),transparent_18%)]" />
      <div className="relative mx-auto grid min-h-[calc(100vh-3rem)] max-w-7xl items-stretch overflow-hidden rounded-[36px] border border-white/10 bg-[#091018]/80 shadow-[0_40px_120px_rgba(0,0,0,0.45)] backdrop-blur-2xl lg:grid-cols-[1.1fr_0.9fr]">
        <div className="hidden min-h-full flex-col justify-between bg-[linear-gradient(180deg,rgba(255,255,255,0.08),rgba(255,255,255,0.02))] p-10 lg:flex">
          <div>
            <img src="/assets/logo-jaecoo-white.png" alt="JAECOO" className="h-8 w-auto opacity-90" />
            <p className="mt-8 max-w-xl text-4xl font-semibold leading-tight text-white">
              JAECOO Yogyakarta <span className="text-gradient">Service Management System</span>
            </p>
            <p className="mt-4 max-w-lg text-sm leading-7 text-white/66">
              Sistem operasional premium untuk frontdesk, manajer, admin, dan mekanik. Cepat diakses, rapi di semua perangkat,
              dan siap menampilkan identitas visual JAECOO secara kuat.
            </p>
          </div>

          <div className="relative overflow-hidden rounded-[30px] border border-white/10 bg-white/5 p-4">
            <img src="/assets/img2.webp" alt="JAECOO Product" className="h-[360px] w-full rounded-[24px] object-cover opacity-90" />
            <div className="absolute inset-x-6 bottom-6 glass rounded-[24px] p-5">
              <p className="text-xs uppercase tracking-[0.28em] text-white/55">Premium automotive workflow</p>
              <p className="mt-2 text-lg font-semibold text-white">Liquid glass dashboard yang tetap efisien untuk operasional harian.</p>
            </div>
          </div>
        </div>

        <div className="relative flex items-center justify-center p-4 md:p-8">
          <div className="w-full max-w-xl">
            <Outlet />
          </div>
        </div>
      </div>
    </div>
  );
}
