import { useState } from 'react';
import { Link, NavLink, Outlet, useNavigate } from 'react-router-dom';
import { appRoutes } from '@/config/route.config';
import { useAuthStore } from '@/modules/auth/store/auth-store';
import { Button } from '@/common/components/ui/button';

export function MechanicLayout() {
  const navigate = useNavigate();
  const clearSession = useAuthStore((state) => state.clearSession);
  const [open, setOpen] = useState(false);

  const menu = (
    <div className="flex h-full flex-col">
      <Link to="/mechanic/tasks" className="rounded-[24px] border border-white/10 bg-white/8 p-5" onClick={() => setOpen(false)}>
        <p className="text-xs uppercase tracking-[0.28em] text-white/45">Mekanik Panel</p>
        <p className="mt-3 text-xl font-semibold">JAECOO Service Tasks</p>
        <p className="mt-2 text-sm text-white/58">Ringkas, cepat, dan nyaman dipakai di tablet maupun ponsel.</p>
      </Link>
      <nav className="mt-5 space-y-2">
        {appRoutes.mechanic.map((route) => (
          <NavLink
            key={route.path}
            to={route.path}
            onClick={() => setOpen(false)}
            className={({ isActive }) =>
              [
                'block rounded-[22px] border p-4 transition',
                isActive ? 'border-[#d9be89]/30 bg-white/12' : 'border-transparent hover:bg-white/8',
              ].join(' ')
            }
          >
            <p className="text-sm font-semibold">{route.label}</p>
            <p className="mt-1 text-xs text-white/50">{route.description}</p>
          </NavLink>
        ))}
      </nav>
      <div className="mt-auto pt-5">
        <Button
          variant="ghost"
          className="w-full"
          onClick={() => {
            clearSession();
            navigate('/login', { replace: true });
          }}
        >
          Keluar
        </Button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen md:p-4">
      <div className="relative min-h-screen md:min-h-[calc(100vh-2rem)] md:overflow-hidden md:rounded-[34px] md:border md:border-white/10 md:bg-white/5 md:backdrop-blur-2xl">
        <div className="flex min-h-screen md:min-h-[calc(100vh-2rem)]">
          <aside className="glass hidden w-[300px] shrink-0 border-r border-white/10 p-5 lg:block">{menu}</aside>
          {open && (
            <div className="fixed inset-0 z-50 bg-black/60 lg:hidden" onClick={() => setOpen(false)}>
              <aside className="glass-mobile h-full w-[86%] max-w-[300px] p-5" onClick={(e) => e.stopPropagation()}>{menu}</aside>
            </div>
          )}
          <div className="min-w-0 flex-1">
            <header className="sticky top-0 z-30 border-b border-white/8 bg-[#071019]/72 px-4 py-3 backdrop-blur-xl md:px-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <button type="button" className="inline-flex h-11 w-11 items-center justify-center rounded-2xl border border-white/10 bg-white/8 text-xl lg:hidden" onClick={() => setOpen(true)}>☰</button>
                  <div>
                    <p className="text-xs uppercase tracking-[0.24em] text-white/42">Mode mekanik</p>
                    <p className="text-sm font-medium text-white/90">Focus, update, complete</p>
                  </div>
                </div>
                <Button variant="secondary" onClick={() => navigate('/services')}>Board Servis</Button>
              </div>
            </header>
            <main className="page-shell animate-fade-up"><Outlet /></main>
          </div>
        </div>
      </div>
    </div>
  );
}
