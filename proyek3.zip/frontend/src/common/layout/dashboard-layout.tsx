import { useMemo, useState } from 'react';
import { Link, NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { appRoutes } from '@/config/route.config';
import { useAuthStore } from '@/modules/auth/store/auth-store';
import { Button } from '@/common/components/ui/button';
import { Card } from '@/common/components/ui/card';
import { hasPermission, roleDescriptions, roleLabels } from '@/common/lib/authz';

export function DashboardLayout() {
  const navigate = useNavigate();
  const location = useLocation();
  const user = useAuthStore((state) => state.user);
  const clearSession = useAuthStore((state) => state.clearSession);
  const [open, setOpen] = useState(false);

  const allowedRoutes = useMemo(
    () => appRoutes.main.filter((route) => hasPermission(user?.role, route.permission)),
    [user?.role],
  );

  const sidebar = (
    <div className="flex h-full flex-col">
      <Link to="/dashboard" className="rounded-[26px] border border-white/8 bg-white/6 p-5" onClick={() => setOpen(false)}>
        <img src="/assets/logo-jaecoo-white.png" alt="JAECOO" className="h-7 w-auto opacity-90" />
        <p className="mt-4 text-lg font-semibold">Yogyakarta Service Management</p>
        <p className="mt-2 text-sm leading-6 text-white/60">Premium workshop operations console dengan nuansa Liquid Glass.</p>
      </Link>

      <Card className="mt-5 p-4">
        <p className="text-[11px] uppercase tracking-[0.28em] text-white/45">Akun aktif</p>
        <p className="mt-3 text-lg font-semibold">{user?.email}</p>
        <p className="mt-1 text-sm text-[#e3c993]">{roleLabels[user?.role ?? 'ADMIN']}</p>
        <p className="mt-3 text-sm leading-6 text-white/62">{roleDescriptions[user?.role ?? 'ADMIN']}</p>
      </Card>

      <nav className="mt-5 flex-1 space-y-2 overflow-auto pr-1">
        {allowedRoutes.map((route) => (
          <NavLink
            key={route.path}
            to={route.path}
            onClick={() => setOpen(false)}
            className={({ isActive }) =>
              [
                'block rounded-[22px] border p-4 transition duration-200',
                isActive
                  ? 'border-[#d9be89]/30 bg-white/12 shadow-[0_16px_40px_rgba(0,0,0,0.22)]'
                  : 'border-transparent bg-transparent text-white/75 hover:border-white/8 hover:bg-white/6 hover:text-white',
              ].join(' ')
            }
          >
            <p className="text-sm font-semibold">{route.label}</p>
            <p className="mt-1 text-xs leading-5 text-white/52">{route.description}</p>
          </NavLink>
        ))}
      </nav>

      <div className="mt-5 grid grid-cols-2 gap-3">
        <Button variant="secondary" onClick={() => navigate('/work-orders/new')}>
          WO Baru
        </Button>
        <Button
          variant="ghost"
          onClick={() => {
            clearSession();
            navigate('/login', { replace: true });
          }}
        >
          Keluar
        </Button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen md:p-4">
      <div className="relative min-h-screen md:min-h-[calc(100vh-2rem)] md:overflow-hidden md:rounded-[34px] md:border md:border-white/10 md:bg-white/5 md:backdrop-blur-2xl">
        <div className="flex min-h-screen md:min-h-[calc(100vh-2rem)]">
          <aside className="glass hidden w-[320px] shrink-0 border-r border-white/10 p-5 xl:block">{sidebar}</aside>

          {open && (
            <div className="fixed inset-0 z-50 bg-black/55 xl:hidden" onClick={() => setOpen(false)}>
              <aside
                className="glass-mobile h-full w-[86%] max-w-[320px] p-5"
                onClick={(event) => event.stopPropagation()}
              >
                {sidebar}
              </aside>
            </div>
          )}

          <div className="min-w-0 flex-1">
            <header className="sticky top-0 z-30 border-b border-white/8 bg-[#071019]/72 px-4 py-3 backdrop-blur-xl md:px-6 xl:px-8">
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    className="inline-flex h-11 w-11 items-center justify-center rounded-2xl border border-white/10 bg-white/8 text-xl text-white xl:hidden"
                    onClick={() => setOpen(true)}
                    aria-label="Buka navigasi"
                  >
                    ☰
                  </button>
                  <div>
                    <p className="text-xs uppercase tracking-[0.24em] text-white/40">JAECOO Yogyakarta</p>
                    <h1 className="text-sm font-medium text-white/90 md:text-base">
                      {allowedRoutes.find((item) => location.pathname.startsWith(item.path))?.label ?? 'Dashboard'}
                    </h1>
                  </div>
                </div>

                <div className="hidden items-center gap-3 md:flex">
                  <div className="rounded-full border border-white/10 bg-white/8 px-4 py-2 text-xs text-white/65">No self-register · Akun dikelola admin</div>
                  <Button variant="secondary" onClick={() => navigate('/services')}>Lihat Board</Button>
                </div>
              </div>
            </header>

            <main className="page-shell animate-fade-up">
              <Outlet />
            </main>
          </div>
        </div>
      </div>
    </div>
  );
}
