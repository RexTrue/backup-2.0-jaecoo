import { Badge } from '@/common/components/ui/badge';
import { ServiceStatus } from '@/common/types/domain';

const statusClassMap: Record<ServiceStatus, string> = {
  ANTRIAN: 'border-white/10 bg-white/8 text-white/80',
  DIKERJAKAN: 'border-sky-300/20 bg-sky-400/14 text-sky-100',
  TEST_DRIVE: 'border-violet-300/20 bg-violet-400/14 text-violet-100',
  SELESAI: 'border-emerald-300/20 bg-emerald-400/14 text-emerald-100',
  DIAMBIL: 'border-teal-300/20 bg-teal-400/14 text-teal-100',
  TERKENDALA: 'border-amber-300/20 bg-amber-400/14 text-amber-100',
};

export function StatusBadge({ status }: { status: ServiceStatus }) {
  return <Badge className={statusClassMap[status]}>{status.replace('_', ' ')}</Badge>;
}
