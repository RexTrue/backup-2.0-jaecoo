import { PropsWithChildren } from 'react';
import { cn } from '@/common/utils/cn';

export function Badge({ children, className }: PropsWithChildren<{ className?: string }>) {
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-full border border-white/10 bg-white/8 px-3 py-1 text-xs font-semibold text-white/85',
        className,
      )}
    >
      {children}
    </span>
  );
}
