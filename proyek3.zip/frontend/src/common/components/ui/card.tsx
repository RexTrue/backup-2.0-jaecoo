import { PropsWithChildren } from 'react';
import { cn } from '@/common/utils/cn';

export function Card({ children, className }: PropsWithChildren<{ className?: string }>) {
  return (
    <section
      className={cn(
        'glass rounded-[28px] p-5 text-white/95 transition duration-300 hover:-translate-y-0.5 hover:border-white/20',
        className,
      )}
    >
      {children}
    </section>
  );
}
