import { ButtonHTMLAttributes } from 'react';
import { cn } from '@/common/utils/cn';

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
};

export function Button({ className, variant = 'primary', ...props }: ButtonProps) {
  return (
    <button
      className={cn(
        'inline-flex min-h-11 items-center justify-center rounded-2xl border px-4 py-2.5 text-sm font-medium transition duration-200 disabled:cursor-not-allowed disabled:opacity-60',
        variant === 'primary' &&
          'border-[#d9be89]/30 bg-gradient-to-b from-[#dbc38d] to-[#b18a4e] text-slate-950 shadow-[0_14px_40px_rgba(197,167,109,0.28)] hover:brightness-105',
        variant === 'secondary' &&
          'border-white/10 bg-white/10 text-white hover:bg-white/16',
        variant === 'ghost' && 'border-transparent bg-transparent text-white/80 hover:bg-white/8 hover:text-white',
        variant === 'danger' &&
          'border-red-300/20 bg-red-500/80 text-white hover:bg-red-500',
        className,
      )}
      {...props}
    />
  );
}