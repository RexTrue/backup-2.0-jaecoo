import { PropsWithChildren } from 'react';
import { cn } from '@/common/utils/cn';

export function Badge({ children, className }: PropsWithChildren<{ className?: string }>) {
  return (
    <span
      className={cn(
        'inline-flex max-w-full items-center rounded-full border border-white/10 bg-white/8 px-3 py-1 text-xs font-semibold leading-4 text-white/85 whitespace-normal break-words',
        className,
      )}
    >
      {children}
    </span>
  );
}