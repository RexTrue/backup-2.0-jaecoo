import { forwardRef, InputHTMLAttributes } from 'react';
import { cn } from '@/common/utils/cn';

export const Input = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement>>(
  ({ className, ...props }, ref) => (
    <input
      ref={ref}
      className={cn(
        'w-full rounded-2xl border border-white/10 bg-white/8 px-4 py-3 text-sm text-white outline-none placeholder:text-white/40 focus:border-[#d7bd88]/50 focus:bg-white/10',
        className,
      )}
      {...props}
    />
  ),
);

Input.displayName = 'Input';