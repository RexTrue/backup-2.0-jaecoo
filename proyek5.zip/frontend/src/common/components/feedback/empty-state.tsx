export function EmptyState({ message }: { message: string }) {
  return <div className="rounded-[24px] border border-dashed border-white/10 bg-white/6 p-6 text-sm text-white/58">{message}</div>;
}