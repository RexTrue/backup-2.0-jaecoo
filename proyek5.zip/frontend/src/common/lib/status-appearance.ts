import { ServiceStatus } from '@/common/types/domain';

export const serviceStatusLabelMap: Record<ServiceStatus, string> = {
  ANTRIAN: 'ANTRIAN',
  DIKERJAKAN: 'PROSES SERVIS',
  TEST_DRIVE: 'SIAP TEST DRIVE',
  SELESAI: 'SELESAI',
  DIAMBIL: 'DIAMBIL',
  TERKENDALA: 'TERKENDALA',
};

export const serviceStatusBadgeMap: Record<ServiceStatus, string> = {
  ANTRIAN: 'border-slate-200/18 bg-slate-300/18 text-slate-100',
  DIKERJAKAN: 'border-sky-300/30 bg-sky-400/20 text-sky-100',
  TEST_DRIVE: 'border-violet-300/30 bg-violet-400/20 text-violet-100',
  SELESAI: 'border-emerald-300/30 bg-emerald-400/20 text-emerald-100',
  DIAMBIL: 'border-teal-300/30 bg-teal-400/20 text-teal-100',
  TERKENDALA: 'border-rose-300/30 bg-rose-400/20 text-rose-100',
};

export const serviceStatusPanelMap: Record<ServiceStatus, string> = {
  ANTRIAN: 'border-slate-200/14 bg-slate-300/10',
  DIKERJAKAN: 'border-sky-300/16 bg-sky-400/12',
  TEST_DRIVE: 'border-violet-300/16 bg-violet-400/12',
  SELESAI: 'border-emerald-300/16 bg-emerald-400/12',
  DIAMBIL: 'border-teal-300/16 bg-teal-400/12',
  TERKENDALA: 'border-rose-300/16 bg-rose-400/12',
};

export const serviceStatusGlowMap: Record<ServiceStatus, string> = {
  ANTRIAN: 'shadow-[0_20px_60px_rgba(148,163,184,0.12)]',
  DIKERJAKAN: 'shadow-[0_20px_60px_rgba(56,189,248,0.15)]',
  TEST_DRIVE: 'shadow-[0_20px_60px_rgba(167,139,250,0.15)]',
  SELESAI: 'shadow-[0_20px_60px_rgba(52,211,153,0.14)]',
  DIAMBIL: 'shadow-[0_20px_60px_rgba(45,212,191,0.14)]',
  TERKENDALA: 'shadow-[0_20px_60px_rgba(251,113,133,0.16)]',
};
