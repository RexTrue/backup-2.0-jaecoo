import { ServiceHistory } from '@/common/types/domain';

export function ServiceTimeline({ items }: { items: ServiceHistory[] }) {
  return (
    <ol className="space-y-4">
      {items.map((item, index) => (
        <li key={item.id_riwayat} className="relative pl-7">
          <span className="absolute left-0 top-1.5 h-3 w-3 rounded-full bg-[#e0c48e] shadow-[0_0_0_6px_rgba(224,196,142,0.12)]" />
          {index !== items.length - 1 && <span className="absolute left-[5px] top-5 h-[calc(100%+0.8rem)] w-px bg-white/12" />}
          <p className="text-sm font-semibold text-white">{item.status.replace('_', ' ')}</p>
          <p className="mt-1 text-xs text-white/50">{new Date(item.waktu).toLocaleString('id-ID')}</p>
        </li>
      ))}
    </ol>
  );
}