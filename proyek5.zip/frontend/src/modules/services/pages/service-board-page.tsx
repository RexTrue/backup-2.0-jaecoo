import { ServiceBoard } from '@/modules/services/components/service-board';
import { Service } from '@/common/types/domain';

const mockServices: Service[] = [
  { id_servis: 1, id_wo: 101, keluhan: 'Ganti oli, cek rem depan, dan validasi kilometer.', status: 'ANTRIAN', prioritas: 'NORMAL', createdAt: new Date().toISOString() },
  { id_servis: 2, id_wo: 102, keluhan: 'Mesin bergetar saat idle. Butuh inspeksi mounting dan throttle body.', status: 'DIKERJAKAN', prioritas: 'URGENT', createdAt: new Date().toISOString() },
  { id_servis: 3, id_wo: 103, keluhan: 'Test drive akhir setelah service berkala dan balancing.', status: 'TEST_DRIVE', prioritas: 'HIGH', createdAt: new Date().toISOString() },
  { id_servis: 4, id_wo: 104, keluhan: 'Final QC dan penjadwalan penyerahan kendaraan.', status: 'SELESAI', prioritas: 'NORMAL', createdAt: new Date().toISOString() },
  { id_servis: 5, id_wo: 105, keluhan: 'Menunggu sparepart rem belakang.', status: 'TERKENDALA', prioritas: 'HIGH', createdAt: new Date().toISOString() },
  { id_servis: 6, id_wo: 106, keluhan: 'Kendaraan siap diambil.', status: 'DIAMBIL', prioritas: 'NORMAL', createdAt: new Date().toISOString() },
];

export function ServiceBoardPage() {
  return (
    <div className="space-y-5">
      <div>
        <p className="text-xs uppercase tracking-[0.28em] text-white/42">Servis</p>
        <h1 className="section-title mt-3">Board Servis</h1>
      </div>
      <ServiceBoard services={mockServices} />
    </div>
  );
}
