import { PriorityLevel, ServiceStatus } from '@/common/types/domain';

export interface UpdateServiceStatusPayload {
  status: ServiceStatus;
  note?: string;
}

export interface ServiceFilter {
  status?: ServiceStatus;
  priority?: PriorityLevel;
  keyword?: string;
  mechanicId?: number;
}