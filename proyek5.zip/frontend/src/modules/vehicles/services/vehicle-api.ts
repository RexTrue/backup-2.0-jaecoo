import { apiClient } from '@/services/api-client';
import { Vehicle } from '@/common/types/domain';

export async function getVehicles() {
  const { data } = await apiClient.get<Vehicle[]>('/vehicles');
  return data;
}