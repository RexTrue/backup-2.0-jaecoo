import { Card } from '@/common/components/ui/card';
import { getVehicleImageByModel } from '@/common/lib/vehicle-images';

const vehicles = [
  { plate: 'AB 1205 EV', unit: 'JAECOO J5 EV', km: '3.420 km', color: 'Moonlight Silver' },
  { plate: 'AB 7718 SP', unit: 'JAECOO J7 SHS-P', km: '8.140 km', color: 'Forest Black' },
  { plate: 'AB 8808 AR', unit: 'JAECOO J8 ARDIS', km: '6.980 km', color: 'White Pearl' },
  { plate: 'AB 9908 SA', unit: 'JAECOO J8 SHS-P ARDIS', km: '2.610 km', color: 'Ash Blue' },
];

export function VehicleListPage() {
  return (
    <div className="space-y-5">
      <div>
        <p className="text-xs uppercase tracking-[0.28em] text-white/42">Kendaraan</p>
        <h1 className="section-title mt-3">Kendaraan</h1>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 2xl:grid-cols-4">
        {vehicles.map((item) => {
          const image = getVehicleImageByModel(item.unit);

          return (
            <Card key={item.plate} className="overflow-hidden p-0">
              <div className="flex aspect-[16/10] items-center justify-center bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.06),transparent_58%),linear-gradient(180deg,rgba(255,255,255,0.03),rgba(255,255,255,0))] px-4 py-5 sm:px-6">
                <img
                  src={image.src}
                  alt={image.alt}
                  className="h-full w-full max-w-[360px] object-contain"
                />
              </div>
              <div className="space-y-2 border-t border-white/8 p-5">
                <p className="text-xs uppercase tracking-[0.24em] text-white/42">{item.plate}</p>
                <h2 className="text-lg font-semibold leading-snug sm:text-xl">{item.unit}</h2>
                <p className="text-sm text-white/60">Warna: {item.color}</p>
                <p className="text-sm text-white/60">Kilometer: {item.km}</p>
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
