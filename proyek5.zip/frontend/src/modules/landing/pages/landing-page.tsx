import { Link } from 'react-router-dom';
import { Button } from '@/common/components/ui/button';
import { Card } from '@/common/components/ui/card';
import { LandingShell } from '@/modules/landing/components/landing-shell';

const introItems = [
  {
    title: 'Monitoring',
    text: 'Pantau work order, progres servis, dan status kendaraan dalam satu tampilan.',
  },
  {
    title: 'Koordinasi',
    text: 'Frontdesk, manajer, admin, dan mekanik bekerja pada alur yang sama.',
  },
  {
    title: 'Riwayat',
    text: 'Status, catatan mekanik, dan timeline pekerjaan dapat ditinjau kembali.',
  },
];

const footerGroups = [
  ['Dashboard', 'Service Board', 'Vehicles', 'Reports'],
  ['Work Orders', 'Customers', 'Schedule', 'Users'],
];

export default function LandingPage() {
  return (
    <div className="min-h-screen">
      <LandingShell>
        <div className="space-y-8 py-4 md:space-y-10 md:py-6">
          <section className="grid gap-6 xl:grid-cols-[1.1fr_0.9fr] xl:items-stretch">
            <Card className="relative overflow-hidden p-6 md:p-8 xl:p-10">
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(217,190,137,0.18),transparent_36%),radial-gradient(circle_at_bottom_right,rgba(155,193,255,0.14),transparent_38%)]" />
              <div className="relative z-10 flex h-full flex-col justify-between gap-8">
                <div className="space-y-5">
                  <img src="/assets/logo-jaecoo-white.png" alt="JAECOO" className="h-10 w-auto opacity-95 md:h-12" />
                  <div>
                    <p className="text-xs uppercase tracking-[0.28em] text-white/45">JAECOO Yogyakarta</p>
                    <h1 className="mt-4 max-w-3xl text-4xl font-semibold tracking-tight md:text-5xl xl:text-6xl">
                      Service Management System
                    </h1>
                    <p className="mt-4 max-w-2xl text-sm leading-7 text-white/68 md:text-base">
                      Sistem untuk pengelolaan work order, progres servis, data kendaraan, pelanggan, jadwal,
                      dan laporan bengkel.
                    </p>
                  </div>
                </div>

                <div className="flex flex-col items-stretch gap-3 sm:flex-row sm:flex-wrap sm:items-center">
                  <Link to="/login" className="w-full sm:w-auto">
                    <Button className="h-14 w-full min-w-[240px] px-12 text-base font-semibold shadow-[0_16px_40px_rgba(212,169,82,0.32)] sm:w-auto">
                      Masuk Sistem
                    </Button>
                  </Link>
                  <div className="rounded-2xl border border-white/10 bg-white/6 px-4 py-3 text-sm text-white/60">
                    Akses akun dikelola admin.
                  </div>
                </div>
              </div>
            </Card>

            <div className="grid gap-6">
              <Card className="overflow-hidden p-0">
                <img src="/assets/img2.webp" alt="JAECOO" className="h-[240px] w-full object-cover md:h-[280px] xl:h-full" />
              </Card>
            </div>
          </section>

          <section className="grid gap-6 lg:grid-cols-3">
            {introItems.map((item) => (
              <Card key={item.title} className="h-full">
                <p className="text-xs uppercase tracking-[0.22em] text-white/42">{item.title}</p>
                <p className="mt-4 text-base leading-7 text-white/80">{item.text}</p>
              </Card>
            ))}
          </section>

          <section>
            <Card className="overflow-hidden p-0">
              <img src="/assets/img3.webp" alt="JAECOO vehicle" className="h-full min-h-[260px] w-full object-cover" />
            </Card>
          </section>
        </div>
      </LandingShell>

      <footer className="mt-10 border-t border-white/10 bg-black/10 backdrop-blur-md">
        <LandingShell>
          <div className="grid gap-8 py-8 md:grid-cols-[1.1fr_1fr_1fr] md:py-10">
            <div>
              <p className="text-lg font-semibold text-white">JAECOO Service Management</p>
              <p className="mt-2 text-sm text-white/62">Yogyakarta</p>
            </div>

            {footerGroups.map((group, idx) => (
              <div key={idx} className="grid gap-3 text-sm text-white/70 sm:grid-cols-2 md:grid-cols-1">
                {group.map((item) => (
                  <div key={item}>{item}</div>
                ))}
              </div>
            ))}
          </div>

          <div className="border-t border-white/10 py-4 text-sm text-white/50 md:flex md:items-center md:justify-between">
            <div>© 2026 JAECOO</div>
            <div className="mt-2 md:mt-0">JAECOO Yogyakarta Service Management System</div>
          </div>
        </LandingShell>
      </footer>
    </div>
  );
}
