import { apiClient } from '@/services/api-client';
import { Customer } from '@/common/types/domain';

export async function getCustomers() {
  const { data } = await apiClient.get<Customer[]>('/customers');
  return data;
}