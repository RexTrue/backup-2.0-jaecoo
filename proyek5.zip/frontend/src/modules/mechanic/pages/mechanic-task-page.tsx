import { Card } from '@/common/components/ui/card';
import { StatusBadge } from '@/common/components/data-display/status-badge';
import { Button } from '@/common/components/ui/button';
import { PriorityLevel, ServiceStatus } from '@/common/types/domain';
import { serviceStatusGlowMap, serviceStatusPanelMap } from '@/common/lib/status-appearance';

const mechanicTasks = [
  {
    id: '#SRV-102',
    customer: 'Budi Santoso',
    vehicle: 'JAECOO J7 · AB 1234 JQ',
    issue: 'Mesin bergetar saat idle dan bunyi pada rem depan.',
    status: 'DIKERJAKAN' as const,
    priority: 'URGENT' as PriorityLevel,
  },
  {
    id: '#SRV-104',
    customer: 'Sari Wulandari',
    vehicle: 'JAECOO J8 · AB 9912 OO',
    issue: 'Cek berkala 10.000 km dan evaluasi test drive.',
    status: 'TEST_DRIVE' as const,
    priority: 'HIGH' as PriorityLevel,
  },
  {
    id: '#SRV-108',
    customer: 'Rama Pradana',
    vehicle: 'JAECOO J7 · AB 1124 KH',
    issue: 'Menunggu approval penggantian rem belakang.',
    status: 'TERKENDALA' as const,
    priority: 'URGENT' as PriorityLevel,
  },
];

const statusSummary: { status: ServiceStatus; value: string }[] = [
  { status: 'DIKERJAKAN', value: '3' },
  { status: 'TEST_DRIVE', value: '1' },
  { status: 'TERKENDALA', value: '1' },
  { status: 'SELESAI', value: '2' },
];

const priorityTone = {
  NORMAL: 'border-white/10 bg-white/6 text-white/72',
  HIGH: 'border-amber-300/24 bg-amber-400/14 text-amber-100',
  URGENT: 'border-rose-300/24 bg-rose-400/14 text-rose-100',
} as const;

export function MechanicTaskPage() {
  return (
    <div className="space-y-5">
      <section className="grid gap-4 xl:grid-cols-[0.95fr_1.05fr]">
        <Card>
          <p className="text-xs uppercase tracking-[0.28em] text-white/42">Mekanik</p>
          <h1 className="section-title mt-3">Tugas Saya</h1>
          <div className="mt-6 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            {statusSummary.map((item) => (
              <div key={item.status} className={`rounded-[22px] border p-4 ${serviceStatusPanelMap[item.status]} ${serviceStatusGlowMap[item.status]}`}>
                <StatusBadge status={item.status} />
                <p className="mt-4 text-3xl font-semibold tracking-tight text-white">{item.value}</p>
              </div>
            ))}
          </div>
        </Card>

        <Card className="rounded-[28px] border border-sky-300/22 bg-sky-400/12 shadow-[0_20px_60px_rgba(56,189,248,0.16)]">
          <p className="text-xs uppercase tracking-[0.28em] text-white/45">Fokus</p>
          <div className="mt-4 space-y-3">
            <div className="rounded-[20px] border border-white/10 bg-black/16 p-4">
              <div className="flex items-center justify-between gap-3">
                <p className="text-sm font-semibold text-white">Unit berikutnya untuk test drive</p>
                <StatusBadge status="TEST_DRIVE" />
              </div>
              <p className="mt-3 text-sm text-white/66">JAECOO J8 · AB 9912 OO</p>
            </div>
            <div className="rounded-[20px] border border-rose-300/20 bg-rose-400/12 p-4">
              <div className="flex items-center justify-between gap-3">
                <p className="text-sm font-semibold text-white">Approval tambahan</p>
                <StatusBadge status="TERKENDALA" />
              </div>
              <p className="mt-3 text-sm text-white/66">1 unit menunggu keputusan penggantian part</p>
            </div>
          </div>
        </Card>
      </section>

      <div className="grid gap-4 xl:grid-cols-2">
        {mechanicTasks.map((task) => (
          <Card key={task.id} className={`space-y-4 border ${serviceStatusPanelMap[task.status]} ${serviceStatusGlowMap[task.status]}`}>
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-[11px] uppercase tracking-[0.24em] text-white/42">{task.id}</p>
                <h2 className="mt-2 text-xl font-semibold text-white">{task.vehicle}</h2>
                <p className="mt-1 text-sm text-white/60">Pelanggan: {task.customer}</p>
              </div>
              <StatusBadge status={task.status} />
            </div>
            <p className="text-sm text-white/72">Keluhan: {task.issue}</p>
            <div className={`inline-flex rounded-[18px] border px-4 py-3 text-sm font-medium ${priorityTone[task.priority]}`}>
              Prioritas {task.priority}
            </div>
            <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
              <Button variant="secondary">Mulai</Button>
              <Button variant="secondary">Catatan</Button>
              <Button variant="secondary">Test Drive</Button>
              <Button>Finish</Button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
