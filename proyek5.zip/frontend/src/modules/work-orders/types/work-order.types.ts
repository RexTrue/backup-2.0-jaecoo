import { PriorityLevel } from '@/common/types/domain';

export interface CreateWorkOrderPayload {
  nik: string;
  no_rangka: string;
  keluhan: string;
  prioritas: PriorityLevel;
  estimasiSelesai?: string;
  jenisServisIds: number[];
}