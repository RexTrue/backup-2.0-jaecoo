import { Card } from '@/common/components/ui/card';

const workOrderStates = [
  { label: 'WO Aktif', value: '14', note: 'Board' },
  { label: 'Menunggu Sparepart', value: '2', note: 'Tindak lanjut' },
  { label: 'Selesai Hari Ini', value: '9', note: 'Selesai' },
];

export function WorkOrderListPage() {
  return (
    <div className="space-y-5">
      <div>
        <p className="text-xs uppercase tracking-[0.28em] text-white/42">Work Order</p>
        <h1 className="section-title mt-3">Work Order</h1>
      </div>
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {workOrderStates.map((item) => (
          <Card key={item.label}>
            <p className="text-sm text-white/55">{item.label}</p>
            <p className="mt-3 text-4xl font-semibold">{item.value}</p>
            <p className="mt-4 text-sm text-white/58">{item.note}</p>
          </Card>
        ))}
      </div>
    </div>
  );
}
