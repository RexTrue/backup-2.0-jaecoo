import { apiClient } from '@/services/api-client';
import { CreateWorkOrderPayload } from '@/modules/work-orders/types/work-order.types';

export async function getWorkOrders() {
  const { data } = await apiClient.get('/work-orders');
  return data;
}

export async function createWorkOrder(payload: CreateWorkOrderPayload) {
  const { data } = await apiClient.post('/work-orders', payload);
  return data;
}