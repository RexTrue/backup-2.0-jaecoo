import { PropsWithChildren } from 'react';
import { cn } from '@/common/utils/cn';

export function Card({ children, className }: PropsWithChildren<{ className?: string }>) {
  return (
    <section
      className={cn(
        'glass rounded-[28px] p-5 theme-text transition duration-300 hover:-translate-y-1 hover:shadow-[0_28px_80px_rgba(0,0,0,0.18)] hover:border-[color:var(--line-strong)]',
        className,
      )}
    >
      {children}
    </section>
  );
}
