import { useTheme } from '@/common/theme/theme-provider';

export function ThemeToggle() {
  const { theme, toggleTheme } = useTheme();
  const nextTheme = theme === 'dark' ? 'light' : 'dark';

  return (
    <button
      type="button"
      onClick={toggleTheme}
      aria-label={`Ganti ke mode ${nextTheme === 'dark' ? 'gelap' : 'terang'}`}
      title={`Mode ${nextTheme === 'dark' ? 'gelap' : 'terang'}`}
      className="fixed right-4 top-4 z-[90] inline-flex h-12 items-center gap-2 rounded-full border border-[color:var(--line)] bg-[color:var(--panel-strong)] px-3 text-sm font-semibold text-[color:var(--text)] shadow-[0_20px_50px_rgba(0,0,0,0.2)] backdrop-blur-2xl transition duration-300 hover:-translate-y-0.5 hover:shadow-[0_24px_60px_rgba(0,0,0,0.24)] md:right-6 md:top-6"
    >
      <span className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-[color:var(--panel-light)] text-base shadow-inner">
        {theme === 'dark' ? '☀' : '☾'}
      </span>
      <span className="hidden sm:inline">{theme === 'dark' ? 'Light' : 'Dark'}</span>
    </button>
  );
}
