import { useMemo, useState } from 'react';
import { Link, NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { appRoutes } from '@/config/route.config';
import { useAuthStore } from '@/modules/auth/store/auth-store';
import { Button } from '@/common/components/ui/button';
import { Card } from '@/common/components/ui/card';
import { hasPermission, roleLabels } from '@/common/lib/authz';
import { ThemeLogo } from '@/common/components/ui/theme-logo';

export function DashboardLayout() {
  const navigate = useNavigate();
  const location = useLocation();
  const user = useAuthStore((state) => state.user);
  const clearSession = useAuthStore((state) => state.clearSession);
  const [open, setOpen] = useState(false);

  const allowedRoutes = useMemo(
    () => appRoutes.main.filter((route) => hasPermission(user?.role, route.permission)),
    [user?.role],
  );

  const currentRoute = allowedRoutes.find((item) => location.pathname.startsWith(item.path));

  const sidebar = (
    <div className="flex h-full flex-col">
      <Link to="/dashboard" className="glass-soft rounded-[26px] p-5" onClick={() => setOpen(false)}>
        <ThemeLogo alt="JAECOO" className="h-8 w-auto opacity-95" />
        <p className="mt-4 max-w-[12ch] text-2xl font-semibold leading-tight text-gradient md:text-[2rem]">Yogyakarta Service Management</p>
      </Link>

      <Card className="mt-5 p-4">
        <p className="text-[11px] uppercase tracking-[0.28em] theme-muted">Akun</p>
        <p className="mt-3 break-all text-lg font-semibold theme-text">{user?.email}</p>
        <p className="mt-1 text-sm text-gradient-accent">{roleLabels[user?.role ?? 'ADMIN']}</p>
      </Card>

      <nav className="mt-5 flex-1 space-y-2 overflow-auto pr-1">
        {allowedRoutes.map((route) => (
          <NavLink
            key={route.path}
            to={route.path}
            end={route.path === '/dashboard'}
            onClick={() => setOpen(false)}
            className={({ isActive }) =>
              [
                'group relative block overflow-hidden rounded-[22px] border p-4 transition duration-300',
                isActive
                  ? 'theme-line bg-[linear-gradient(135deg,var(--accent-soft),color-mix(in_srgb,var(--panel-light)_82%,transparent))] shadow-[0_18px_42px_rgba(0,0,0,0.12)]'
                  : 'border-transparent bg-transparent hover:border-[color:var(--line)] hover:bg-[color:var(--panel-light)]',
              ].join(' ')
            }
          >
            {({ isActive }) => (
              <div className="flex items-center gap-3">
                <span
                  className={[
                    'h-2.5 w-2.5 rounded-full transition duration-200',
                    isActive ? 'bg-[color:var(--accent)] shadow-[0_0_0_6px_var(--accent-soft)]' : 'bg-[color:var(--muted)]/35 group-hover:bg-[color:var(--accent)]/70',
                  ].join(' ')}
                />
                <p className={['text-sm font-semibold', isActive ? 'theme-text' : 'theme-muted'].join(' ')}>{route.label}</p>
                {isActive && <span className="ml-auto h-8 w-1.5 rounded-full bg-[color:var(--accent)]" />}
              </div>
            )}
          </NavLink>
        ))}
      </nav>

      <div className="mt-5 grid grid-cols-2 gap-3">
        <Button variant="secondary" onClick={() => navigate('/work-orders/new')}>
          WO Baru
        </Button>
        <Button
          variant="ghost"
          onClick={() => {
            clearSession();
            navigate('/login', { replace: true });
          }}
        >
          Keluar
        </Button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen md:p-4">
      <div className="relative min-h-screen md:min-h-[calc(100vh-2rem)] md:rounded-[34px] md:border md:border-[color:var(--line)] md:bg-[color:var(--panel-light)]/35 md:backdrop-blur-2xl">
        <div className="flex min-h-screen items-start md:min-h-[calc(100vh-2rem)]">
          <aside className="glass sticky top-4 hidden h-[calc(100vh-2rem)] w-[320px] shrink-0 border-r border-[color:var(--line)] p-5 xl:block">
            {sidebar}
          </aside>

          {open && (
            <div className="fixed inset-0 z-50 bg-black/45 xl:hidden" onClick={() => setOpen(false)}>
              <aside className="glass-mobile h-full w-[86%] max-w-[320px] p-5" onClick={(event) => event.stopPropagation()}>
                {sidebar}
              </aside>
            </div>
          )}

          <div className="min-w-0 flex-1">
            <header className="topbar-surface sticky top-0 z-30 border-b px-4 py-3 backdrop-blur-xl md:px-6 xl:px-8">
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    className="inline-flex h-11 w-11 items-center justify-center rounded-2xl border border-[color:var(--line)] bg-[color:var(--panel-light)] text-xl theme-text xl:hidden"
                    onClick={() => setOpen(true)}
                    aria-label="Buka navigasi"
                  >
                    ☰
                  </button>
                  <div>
                    <p className="text-xs uppercase tracking-[0.24em] theme-muted">JAECOO Yogyakarta</p>
                    <h1 className="text-sm font-medium theme-text md:text-base">{currentRoute?.label ?? 'Dashboard'}</h1>
                  </div>
                </div>

                <div className="hidden items-center gap-3 md:flex">
                  <Button variant="secondary" onClick={() => navigate('/services')}>Board</Button>
                </div>
              </div>
            </header>

            <main className="page-shell animate-fade-up">
              <Outlet />
            </main>
          </div>
        </div>
      </div>
    </div>
  );
}
