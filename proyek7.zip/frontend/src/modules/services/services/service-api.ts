import { apiClient } from '@/services/api-client';
import { Service } from '@/common/types/domain';
import { UpdateServiceStatusPayload } from '@/modules/services/types/service.types';
import { mapServiceFromBackend } from '@/common/lib/backend-mappers';

export async function getServices() {
  const { data } = await apiClient.get<Record<string, unknown>[]>('/services');
  return data.map(mapServiceFromBackend) as Service[];
}

export async function getServiceDetail(serviceId: string) {
  const { data } = await apiClient.get<Record<string, unknown>>(`/services/${serviceId}`);
  return mapServiceFromBackend(data) as Service;
}

export async function updateServiceStatus(serviceId: string, payload: UpdateServiceStatusPayload) {
  const { data } = await apiClient.patch<Record<string, unknown>>(`/services/${serviceId}/status`, payload);
  return mapServiceFromBackend(data) as Service;
}
