import { Card } from '@/common/components/ui/card';
import { StatusBadge } from '@/common/components/data-display/status-badge';
import { ServiceTimeline } from '@/modules/services/components/service-timeline';
import { useAuthStore } from '@/modules/auth/store/auth-store';
import { roleLabels } from '@/common/lib/authz';

const timeline = [
  { id_riwayat: 1, id_servis: 10, status: 'ANTRIAN' as const, waktu: new Date().toISOString() },
  { id_riwayat: 2, id_servis: 10, status: 'DIKERJAKAN' as const, waktu: new Date().toISOString() },
  { id_riwayat: 3, id_servis: 10, status: 'TEST_DRIVE' as const, waktu: new Date().toISOString() },
];

export function ServiceDetailPage() {
  const user = useAuthStore((state) => state.user);
  const role = user?.role ?? 'ADMIN';

  return (
    <div className="grid gap-5 xl:grid-cols-[1.4fr_0.8fr]">
      <Card>
        <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
          <div>
            <p className="text-xs uppercase tracking-[0.28em] theme-muted">WO #101</p>
            <h1 className="mt-3 text-3xl font-semibold">Servis</h1>
          </div>
          <StatusBadge status="DIKERJAKAN" />
        </div>

        <div className="mt-6 grid gap-4 md:grid-cols-2">
          <div className="rounded-[24px] border border-[color:var(--line)] bg-[color:var(--panel-light)] p-5">
            <h2 className="text-sm font-semibold uppercase tracking-[0.24em] theme-muted">Kendaraan</h2>
            <div className="mt-3 space-y-2 text-sm theme-muted">
              <p>Plat: AB 1234 JQ</p>
              <p>No rangka: MHCJAECOOJ7YOGYA01</p>
              <p>Model: JAECOO J7 AWD</p>
              <p>Kilometer: 12.420 km</p>
            </div>
          </div>
          <div className="rounded-[24px] border border-[color:var(--line)] bg-[color:var(--panel-light)] p-5">
            <h2 className="text-sm font-semibold uppercase tracking-[0.24em] theme-muted">Pelanggan</h2>
            <div className="mt-3 space-y-2 text-sm theme-muted">
              <p>Nama: Budi Santoso</p>
              <p>No HP: 0812-3456-7890</p>
              <p>User: {roleLabels[role]}</p>
              <p>Estimasi selesai: 16.00 WIB</p>
            </div>
          </div>
        </div>

        <div className="mt-6 rounded-[24px] border border-[color:var(--line)] bg-[color:var(--panel)] p-5">
          <h2 className="text-sm font-semibold uppercase tracking-[0.24em] theme-muted">Keluhan</h2>
          <p className="mt-3 text-sm theme-muted">
            Mesin bergetar saat idle. Cek mounting mesin, throttle body, dan road test.
          </p>
        </div>
      </Card>

      <Card>
        <h2 className="text-xl font-semibold">Timeline</h2>
        <div className="mt-6">
          <ServiceTimeline items={timeline} />
        </div>
      </Card>
    </div>
  );
}
