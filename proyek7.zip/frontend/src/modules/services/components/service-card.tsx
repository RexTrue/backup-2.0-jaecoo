import { Link } from 'react-router-dom';
import { Service } from '@/common/types/domain';
import { Card } from '@/common/components/ui/card';
import { StatusBadge } from '@/common/components/data-display/status-badge';
import { serviceStatusGlowMap, serviceStatusPanelMap } from '@/common/lib/status-appearance';

const priorityMap = {
  NORMAL: 'theme-muted',
  HIGH: 'text-amber-200',
  URGENT: 'text-rose-200',
} as const;

export function ServiceCard({ service }: { service: Service }) {
  return (
    <Link to={`/services/${service.id_servis}`}>
      <Card
        className={`space-y-3 rounded-[24px] border p-4 hover:bg-white/12 ${serviceStatusPanelMap[service.status]} ${serviceStatusGlowMap[service.status]}`}
      >
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-[11px] uppercase tracking-[0.22em] theme-muted">Servis #{service.id_servis}</p>
            <h3 className="mt-2 text-sm font-semibold leading-6 theme-text">{service.keluhan}</h3>
          </div>
          <StatusBadge status={service.status} />
        </div>
        <div className="flex items-center justify-between text-xs theme-muted">
          <span className={priorityMap[service.prioritas]}>Prioritas {service.prioritas}</span>
          <span>WO #{service.id_wo}</span>
        </div>
      </Card>
    </Link>
  );
}
