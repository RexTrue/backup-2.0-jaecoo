import { Card } from '@/common/components/ui/card';
import { Button } from '@/common/components/ui/button';

const userRows = [
  { email: 'admin@service.com', role: 'ADMIN', status: 'Aktif' },
  { email: 'manager@service.com', role: 'MANAGER', status: 'Aktif' },
  { email: 'frontline@service.com', role: 'FRONTLINE', status: 'Aktif' },
  { email: 'mechanic@service.com', role: 'MEKANIK', status: 'Aktif' },
];

export function UserManagementPage() {
  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="text-xs uppercase tracking-[0.28em] theme-muted">User</p>
          <h1 className="section-title mt-3">User</h1>
        </div>
        <Button>Tambah User</Button>
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        {userRows.map((row) => (
          <Card key={row.email}>
            <p className="text-sm font-semibold theme-text">{row.email}</p>
            <p className="mt-3 text-sm theme-muted">Role: {row.role}</p>
            <p className="mt-1 text-sm theme-muted">Status: {row.status}</p>
          </Card>
        ))}
      </div>
    </div>
  );
}
