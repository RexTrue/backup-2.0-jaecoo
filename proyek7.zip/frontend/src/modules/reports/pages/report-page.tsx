import { Card } from '@/common/components/ui/card';

const reportBuckets = [
  { title: 'SLA', items: ['4,2 jam', '3 overdue', '87% sesuai estimasi'] },
  { title: 'Mekanik', items: ['A: 12', 'B: 10', '2 kendala'] },
  { title: 'Kapasitas', items: ['22 masuk', '18 selesai', '4 carry over'] },
];

export function ReportPage() {
  return (
    <div className="space-y-5">
      <div>
        <p className="text-xs uppercase tracking-[0.28em] theme-muted">Laporan</p>
        <h1 className="section-title mt-3">Laporan</h1>
      </div>
      <div className="grid gap-4 xl:grid-cols-3">
        {reportBuckets.map((bucket) => (
          <Card key={bucket.title}>
            <h2 className="text-xl font-semibold theme-text">{bucket.title}</h2>
            <div className="mt-4 space-y-3">
              {bucket.items.map((item) => (
                <div key={item} className="rounded-[20px] border border-[color:var(--line)] bg-[color:var(--panel-light)] px-4 py-3 text-sm theme-muted">{item}</div>
              ))}
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
