import { apiClient } from '@/services/api-client';
import { Customer } from '@/common/types/domain';
import { mapCustomerFromBackend } from '@/common/lib/backend-mappers';

export async function getCustomers() {
  const { data } = await apiClient.get<Record<string, unknown>[]>('/customers');
  return data.map(mapCustomerFromBackend) as Customer[];
}
