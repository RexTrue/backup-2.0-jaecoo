import { Card } from '@/common/components/ui/card';

const customerRows = [
  { name: 'Budi Santoso', nik: '3401123456780001', phone: '0812-3456-7890', units: 2 },
  { name: 'Sari Wulandari', nik: '3401123456780002', phone: '0813-1122-3344', units: 1 },
  { name: 'Andra Pratama', nik: '3401123456780003', phone: '0822-7788-1122', units: 1 },
];

export function CustomerListPage() {
  return (
    <div className="space-y-5">
      <div>
        <p className="text-xs uppercase tracking-[0.28em] theme-muted">Pelanggan</p>
        <h1 className="section-title mt-3">Pelanggan</h1>
      </div>
      <div className="grid gap-4 xl:grid-cols-[0.8fr_1.2fr]">
        <Card>
          <p className="text-sm theme-muted">Data</p>
        </Card>
        <Card>
          <div className="grid gap-3">
            {customerRows.map((row) => (
              <div key={row.nik} className="rounded-[22px] border border-[color:var(--line)] bg-[color:var(--panel-light)] p-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <p className="text-sm font-semibold theme-text">{row.name}</p>
                    <p className="mt-1 text-xs theme-muted">NIK {row.nik}</p>
                  </div>
                  <div className="rounded-full border border-[color:var(--line)] bg-[color:var(--panel)] px-3 py-1 text-xs theme-muted">{row.units} kendaraan</div>
                </div>
                <p className="mt-3 text-sm theme-muted">Kontak: {row.phone}</p>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
