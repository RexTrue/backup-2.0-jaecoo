import { apiClient } from '@/services/api-client';
import { CreateWorkOrderPayload } from '@/modules/work-orders/types/work-order.types';
import { mapWorkOrderFromBackend } from '@/common/lib/backend-mappers';
import { WorkOrder } from '@/common/types/domain';

export async function getWorkOrders() {
  const { data } = await apiClient.get<Record<string, unknown>[]>('/work-orders');
  return data.map(mapWorkOrderFromBackend) as WorkOrder[];
}

export async function createWorkOrder(payload: CreateWorkOrderPayload) {
  const { data } = await apiClient.post<Record<string, unknown>>('/work-orders', payload);
  return mapWorkOrderFromBackend(data) as WorkOrder;
}
