import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button } from '@/common/components/ui/button';
import { Input } from '@/common/components/ui/input';
import { Card } from '@/common/components/ui/card';

const schema = z.object({
  nik: z.string().min(8, 'NIK minimal 8 karakter'),
  no_rangka: z.string().min(5, 'Nomor rangka minimal 5 karakter'),
  keluhan: z.string().min(5, 'Keluhan minimal 5 karakter'),
});

type FormValues = z.infer<typeof schema>;

export function WorkOrderCreatePage() {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<FormValues>({ resolver: zodResolver(schema) });

  return (
    <div className="grid gap-5 xl:grid-cols-[0.72fr_1.28fr]">
      <Card>
        <p className="text-xs uppercase tracking-[0.28em] theme-muted">Work Order</p>
        <h1 className="mt-4 text-3xl font-semibold">Buat Work Order</h1>
      </Card>

      <Card>
        <form className="space-y-4" onSubmit={handleSubmit(() => undefined)}>
          <div>
            <label className="mb-2 block text-xs uppercase tracking-[0.24em] theme-muted">NIK</label>
            <Input placeholder="3401123456780001" {...register('nik')} />
            {errors.nik && <p className="mt-2 text-xs text-red-300">{errors.nik.message}</p>}
          </div>
          <div>
            <label className="mb-2 block text-xs uppercase tracking-[0.24em] theme-muted">Nomor Rangka</label>
            <Input placeholder="MHCJAECOOJ7YOGYA01" {...register('no_rangka')} />
            {errors.no_rangka && <p className="mt-2 text-xs text-red-300">{errors.no_rangka.message}</p>}
          </div>
          <div>
            <label className="mb-2 block text-xs uppercase tracking-[0.24em] theme-muted">Keluhan</label>
            <Input placeholder="Mesin bergetar" {...register('keluhan')} />
            {errors.keluhan && <p className="mt-2 text-xs text-red-300">{errors.keluhan.message}</p>}
          </div>
          <Button type="submit" className="mt-2">Simpan</Button>
        </form>
      </Card>
    </div>
  );
}
