import { apiClient } from '@/services/api-client';
import { Vehicle } from '@/common/types/domain';
import { mapVehicleFromBackend } from '@/common/lib/backend-mappers';

export async function getVehicles() {
  const { data } = await apiClient.get<Record<string, unknown>[]>('/vehicles');
  return data.map(mapVehicleFromBackend) as Vehicle[];
}
