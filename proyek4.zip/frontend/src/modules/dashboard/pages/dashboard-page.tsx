import { Card } from '@/common/components/ui/card';
import { useAuthStore } from '@/modules/auth/store/auth-store';
import { Role, ServiceStatus } from '@/common/types/domain';
import { StatusBadge } from '@/common/components/data-display/status-badge';
import { serviceStatusGlowMap, serviceStatusLabelMap, serviceStatusPanelMap } from '@/common/lib/status-appearance';

type KpiCard = {
  label: string;
  value: string;
  tone: string;
  chip?: string;
};

type FocusCard = {
  label: string;
  value: string;
  chip?: string;
  tone: string;
};

type WorkOrderItem = {
  wo: string;
  plate: string;
  model: string;
  status: ServiceStatus;
  time: string;
};

type TimelineItem = {
  time: string;
  text: string;
  status: ServiceStatus;
};

type PriorityItem = {
  title: string;
  status: ServiceStatus;
  note: string;
};

type DashboardConfig = {
  eyebrow: string;
  heading: string;
  heroImage: string;
  focusCards: FocusCard[];
  kpis: KpiCard[];
  statusCounts: Record<ServiceStatus, number>;
  timeline: TimelineItem[];
  activeList: WorkOrderItem[];
  priorityList: PriorityItem[];
};

const tone = {
  warning: 'border-amber-300/22 bg-amber-400/14 shadow-[0_18px_56px_rgba(251,191,36,0.18)]',
  danger: 'border-rose-300/24 bg-rose-400/14 shadow-[0_18px_56px_rgba(251,113,133,0.18)]',
  info: 'border-sky-300/24 bg-sky-400/14 shadow-[0_18px_56px_rgba(56,189,248,0.18)]',
  success: 'border-emerald-300/24 bg-emerald-400/14 shadow-[0_18px_56px_rgba(52,211,153,0.18)]',
  neutral: 'border-white/10 bg-white/6 shadow-[0_18px_56px_rgba(255,255,255,0.05)]',
};

const adminConfig: DashboardConfig = {
  eyebrow: 'Admin',
  heading: 'Overview',
  heroImage: '/assets/img3.webp',
  focusCards: [
    { label: 'Terkendala', value: '2 unit', chip: 'Perlu tindak lanjut', tone: tone.danger },
    { label: 'Siap Test Drive', value: '3 unit', chip: 'Butuh validasi', tone: tone.info },
    { label: 'Siap Diambil', value: '4 unit', chip: 'Menunggu frontdesk', tone: tone.success },
    { label: 'Antrian Baru', value: '5 unit', chip: 'Masuk hari ini', tone: tone.warning },
  ],
  kpis: [
    { label: 'Kendaraan Masuk', value: '18', chip: '+4', tone: tone.info },
    { label: 'Servis Aktif', value: '11', chip: '+2', tone: tone.warning },
    { label: 'Selesai Hari Ini', value: '7', chip: '+3', tone: tone.success },
    { label: 'Terkendala', value: '2', chip: 'Watch', tone: tone.danger },
  ],
  statusCounts: { ANTRIAN: 5, DIKERJAKAN: 4, TEST_DRIVE: 3, SELESAI: 4, DIAMBIL: 2, TERKENDALA: 2 },
  timeline: [
    { time: '11:24', text: 'WO-240603 berpindah ke test drive', status: 'TEST_DRIVE' },
    { time: '11:05', text: 'WO-240604 ditandai terkendala', status: 'TERKENDALA' },
    { time: '10:42', text: 'WO-240601 mulai dikerjakan', status: 'DIKERJAKAN' },
    { time: '10:10', text: 'WO-240602 masuk antrian', status: 'ANTRIAN' },
  ],
  activeList: [
    { wo: 'WO-240601', plate: 'AB 1234 YK', model: 'J7', status: 'DIKERJAKAN', time: '08:30' },
    { wo: 'WO-240602', plate: 'AB 8890 LX', model: 'J8', status: 'ANTRIAN', time: '09:10' },
    { wo: 'WO-240603', plate: 'AB 9901 QA', model: 'J7', status: 'TEST_DRIVE', time: '10:15' },
    { wo: 'WO-240604', plate: 'AB 4411 BX', model: 'J8', status: 'TERKENDALA', time: '11:00' },
  ],
  priorityList: [
    { title: 'Unit menunggu keputusan', status: 'TERKENDALA', note: 'Konfirmasi sparepart dan estimasi baru' },
    { title: 'Unit siap test drive', status: 'TEST_DRIVE', note: 'Validasi hasil pengerjaan sebelum diserahkan' },
    { title: 'Unit siap diambil', status: 'SELESAI', note: 'Konfirmasi dokumen dan serah terima' },
  ],
};

const managerConfig: DashboardConfig = {
  eyebrow: 'Manajer',
  heading: 'Monitoring',
  heroImage: '/assets/img1.jpg',
  focusCards: [
    { label: 'Terkendala', value: '3 unit', chip: 'Prioritas', tone: tone.danger },
    { label: 'Proses Servis', value: '6 unit', chip: 'Beban bengkel', tone: tone.warning },
    { label: 'Siap Test Drive', value: '2 unit', chip: 'QC', tone: tone.info },
    { label: 'Siap Diambil', value: '5 unit', chip: 'Output hari ini', tone: tone.success },
  ],
  kpis: [
    { label: 'WO Hari Ini', value: '14', chip: '+2', tone: tone.info },
    { label: 'Servis Aktif', value: '13', chip: '+1', tone: tone.warning },
    { label: 'Test Drive', value: '2', chip: 'QC', tone: tone.info },
    { label: 'Terkendala', value: '3', chip: 'Watch', tone: tone.danger },
  ],
  statusCounts: { ANTRIAN: 4, DIKERJAKAN: 6, TEST_DRIVE: 2, SELESAI: 5, DIAMBIL: 2, TERKENDALA: 3 },
  timeline: [
    { time: '11:40', text: 'WO-240607 menunggu approval tambahan', status: 'TERKENDALA' },
    { time: '11:18', text: 'WO-240603 siap test drive', status: 'TEST_DRIVE' },
    { time: '10:58', text: 'WO-240601 masih proses servis', status: 'DIKERJAKAN' },
    { time: '10:22', text: 'WO-240605 masuk antrian', status: 'ANTRIAN' },
  ],
  activeList: [
    { wo: 'WO-240601', plate: 'AB 1234 YK', model: 'J7', status: 'DIKERJAKAN', time: '08:30' },
    { wo: 'WO-240603', plate: 'AB 9901 QA', model: 'J7', status: 'TEST_DRIVE', time: '10:15' },
    { wo: 'WO-240607', plate: 'AB 1199 JL', model: 'J8', status: 'TERKENDALA', time: '11:05' },
    { wo: 'WO-240608', plate: 'AB 7743 PL', model: 'J7', status: 'SELESAI', time: '11:20' },
  ],
  priorityList: [
    { title: 'Approval tambahan', status: 'TERKENDALA', note: 'Tentukan keputusan untuk WO-240607' },
    { title: 'QC siang ini', status: 'TEST_DRIVE', note: '2 unit perlu test drive final' },
    { title: 'Output selesai', status: 'SELESAI', note: '5 unit siap tutup hari ini' },
  ],
};

const frontlineConfig: DashboardConfig = {
  eyebrow: 'Frontdesk',
  heading: 'Desk Overview',
  heroImage: '/assets/img2.webp',
  focusCards: [
    { label: 'Menunggu Pengambilan', value: '4 unit', chip: 'Siap hubungi', tone: tone.success },
    { label: 'Antrian Masuk', value: '6 unit', chip: 'Check-in', tone: tone.warning },
    { label: 'Terkendala', value: '2 unit', chip: 'Perlu update pelanggan', tone: tone.danger },
    { label: 'Siap Test Drive', value: '1 unit', chip: 'Koordinasi', tone: tone.info },
  ],
  kpis: [
    { label: 'Check-in Hari Ini', value: '12', chip: '+3', tone: tone.info },
    { label: 'Siap Diambil', value: '4', chip: 'Call', tone: tone.success },
    { label: 'Antrian', value: '6', chip: 'Desk', tone: tone.warning },
    { label: 'Terkendala', value: '2', chip: 'Watch', tone: tone.danger },
  ],
  statusCounts: { ANTRIAN: 6, DIKERJAKAN: 3, TEST_DRIVE: 1, SELESAI: 4, DIAMBIL: 2, TERKENDALA: 2 },
  timeline: [
    { time: '11:20', text: 'WO-240610 siap diambil', status: 'SELESAI' },
    { time: '10:55', text: 'WO-240611 masuk antrian', status: 'ANTRIAN' },
    { time: '10:40', text: 'WO-240607 perlu update ke pelanggan', status: 'TERKENDALA' },
    { time: '10:05', text: 'WO-240606 dipindah ke proses servis', status: 'DIKERJAKAN' },
  ],
  activeList: [
    { wo: 'WO-240606', plate: 'AB 5512 NT', model: 'J7', status: 'DIKERJAKAN', time: '08:10' },
    { wo: 'WO-240610', plate: 'AB 3401 BY', model: 'J8', status: 'SELESAI', time: '10:35' },
    { wo: 'WO-240611', plate: 'AB 4421 KA', model: 'J7', status: 'ANTRIAN', time: '10:50' },
    { wo: 'WO-240607', plate: 'AB 1199 JL', model: 'J8', status: 'TERKENDALA', time: '11:00' },
  ],
  priorityList: [
    { title: 'Hubungi pelanggan', status: 'SELESAI', note: '4 unit menunggu pengambilan' },
    { title: 'Update kendala', status: 'TERKENDALA', note: 'Sampaikan estimasi revisi ke pelanggan' },
    { title: 'Check-in berikutnya', status: 'ANTRIAN', note: 'Siapkan slot masuk siang ini' },
  ],
};

const mechanicConfig: DashboardConfig = {
  eyebrow: 'Mekanik',
  heading: 'My Queue',
  heroImage: '/assets/img1.jpg',
  focusCards: [
    { label: 'Terkendala', value: '1 unit', chip: 'Perlu keputusan', tone: tone.danger },
    { label: 'Proses Servis', value: '3 unit', chip: 'Sedang dikerjakan', tone: tone.warning },
    { label: 'Siap Test Drive', value: '1 unit', chip: 'QC berikutnya', tone: tone.info },
    { label: 'Selesai Hari Ini', value: '2 unit', chip: 'Shift pagi', tone: tone.success },
  ],
  kpis: [
    { label: 'Task Aktif', value: '4', chip: 'Live', tone: tone.warning },
    { label: 'Selesai', value: '2', chip: 'Hari ini', tone: tone.success },
    { label: 'Test Drive', value: '1', chip: 'QC', tone: tone.info },
    { label: 'Terkendala', value: '1', chip: 'Watch', tone: tone.danger },
  ],
  statusCounts: { ANTRIAN: 1, DIKERJAKAN: 3, TEST_DRIVE: 1, SELESAI: 2, DIAMBIL: 0, TERKENDALA: 1 },
  timeline: [
    { time: '11:24', text: 'WO-240603 berpindah ke test drive', status: 'TEST_DRIVE' },
    { time: '10:52', text: 'WO-240612 mulai dikerjakan', status: 'DIKERJAKAN' },
    { time: '10:31', text: 'WO-240609 menunggu keputusan', status: 'TERKENDALA' },
    { time: '09:50', text: 'WO-240608 selesai servis', status: 'SELESAI' },
  ],
  activeList: [
    { wo: 'WO-240612', plate: 'AB 7782 HL', model: 'J7', status: 'DIKERJAKAN', time: '10:52' },
    { wo: 'WO-240603', plate: 'AB 9901 QA', model: 'J7', status: 'TEST_DRIVE', time: '10:15' },
    { wo: 'WO-240609', plate: 'AB 5501 TR', model: 'J8', status: 'TERKENDALA', time: '10:31' },
    { wo: 'WO-240608', plate: 'AB 7743 PL', model: 'J7', status: 'SELESAI', time: '09:50' },
  ],
  priorityList: [
    { title: 'Unit tertahan', status: 'TERKENDALA', note: 'Menunggu konfirmasi sparepart' },
    { title: 'Unit menuju QC', status: 'TEST_DRIVE', note: 'Satu unit siap test drive final' },
    { title: 'Pekerjaan aktif', status: 'DIKERJAKAN', note: 'Fokus pada 3 unit proses servis' },
  ],
};

function getConfigByRole(role: Role | undefined): DashboardConfig {
  if (role === 'MANAGER') return managerConfig;
  if (role === 'FRONTLINE') return frontlineConfig;
  if (role === 'MEKANIK') return mechanicConfig;
  return adminConfig;
}

function KpiCardView({ card }: { card: KpiCard }) {
  return (
    <Card className={`rounded-[24px] border overflow-hidden ${card.tone}`}>
      <div className="flex items-start justify-between gap-3">
        <p className="min-w-0 text-sm leading-5 text-white/66">{card.label}</p>
        {card.chip ? (
          <span className="shrink-0 rounded-full border border-white/10 bg-black/18 px-2.5 py-1 text-xs text-white/70">{card.chip}</span>
        ) : null}
      </div>
      <p className="mt-5 text-3xl font-semibold tracking-tight text-white md:text-4xl">{card.value}</p>
    </Card>
  );
}

export function DashboardPage() {
  const role = useAuthStore((state) => state.user?.role);
  const config = getConfigByRole(role);
  const orderedStatuses: ServiceStatus[] = ['ANTRIAN', 'DIKERJAKAN', 'TEST_DRIVE', 'SELESAI', 'DIAMBIL', 'TERKENDALA'];

  return (
    <div className="space-y-5">
      <section className="grid gap-4 xl:grid-cols-[1.2fr_0.8fr]">
        <Card className="overflow-hidden">
          <div>
            <p className="text-xs uppercase tracking-[0.28em] text-white/45">{config.eyebrow}</p>
            <h2 className="section-title mt-4">{config.heading}</h2>
            <div className="mt-6 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
              {config.focusCards.map((item) => (
                <div
                  key={item.label}
                  className={`flex min-h-[168px] flex-col justify-between overflow-hidden rounded-[22px] border p-4 ${item.tone}`}
                >
                  <div className="space-y-3">
                    <p className="min-h-[40px] text-sm leading-5 text-white/86">{item.label}</p>
                    {item.chip ? (
                      <span className="inline-flex max-w-full rounded-full border border-white/10 bg-black/18 px-2.5 py-1 text-[11px] leading-4 text-white/72">
                        {item.chip}
                      </span>
                    ) : null}
                  </div>
                  <p className="mt-5 text-2xl font-semibold leading-none tracking-tight text-white md:text-3xl">{item.value}</p>
                </div>
              ))}
            </div>
          </div>
        </Card>

        <Card className="overflow-hidden p-0">
          <img src={config.heroImage} alt="JAECOO" className="h-full min-h-[300px] w-full object-cover" />
        </Card>
      </section>

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {config.kpis.map((item) => (
          <KpiCardView key={item.label} card={item} />
        ))}
      </section>

      <section className="grid gap-4 xl:grid-cols-[1.1fr_0.9fr]">
        <Card>
          <div>
            <p className="text-xs uppercase tracking-[0.28em] text-white/42">Status</p>
            <h3 className="mt-3 text-xl font-semibold">Board Snapshot</h3>
          </div>
          <div className="mt-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
            {orderedStatuses.map((status) => (
              <div key={status} className={`rounded-[22px] border p-4 ${serviceStatusPanelMap[status]} ${serviceStatusGlowMap[status]}`}>
                <div className="space-y-3">
                  <p className="text-sm leading-5 text-white/84">{serviceStatusLabelMap[status]}</p>
                  <StatusBadge status={status} />
                </div>
                <p className="mt-4 text-3xl font-semibold tracking-tight text-white">{config.statusCounts[status]}</p>
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <p className="text-xs uppercase tracking-[0.28em] text-white/42">Timeline</p>
          <div className="mt-5 space-y-3">
            {config.timeline.map((item) => (
              <div key={`${item.time}-${item.text}`} className={`flex gap-4 rounded-[22px] border p-4 ${serviceStatusPanelMap[item.status]}`}>
                <span className="shrink-0 rounded-full border border-white/10 bg-black/18 px-3 py-1 text-xs text-white/55">{item.time}</span>
                <div className="min-w-0 space-y-2">
                  <p className="text-sm leading-6 text-white/88">{item.text}</p>
                  <StatusBadge status={item.status} />
                </div>
              </div>
            ))}
          </div>
        </Card>
      </section>

      <section className="grid gap-4 xl:grid-cols-[1.25fr_0.75fr]">
        <Card>
          <div>
            <p className="text-xs uppercase tracking-[0.28em] text-white/42">Work Order</p>
            <h3 className="mt-3 text-xl font-semibold">Active List</h3>
          </div>

          <div className="mt-5 overflow-hidden rounded-[24px] border border-white/8">
            <div className="grid grid-cols-[1.15fr_1fr_1.2fr_0.8fr] gap-3 border-b border-white/8 bg-white/6 px-4 py-3 text-xs uppercase tracking-[0.18em] text-white/40">
              <span>WO</span>
              <span>Kendaraan</span>
              <span>Status</span>
              <span>Masuk</span>
            </div>
            <div className="divide-y divide-white/8">
              {config.activeList.map((item) => (
                <div key={item.wo} className="grid grid-cols-[1.15fr_1fr_1.2fr_0.8fr] gap-3 px-4 py-4 text-sm text-white/84">
                  <div className="min-w-0">
                    <p className="font-semibold">{item.wo}</p>
                    <p className="mt-1 truncate text-xs text-white/48">{item.plate}</p>
                  </div>
                  <span>{item.model}</span>
                  <div className="min-w-0">
                    <StatusBadge status={item.status} />
                  </div>
                  <span>{item.time}</span>
                </div>
              ))}
            </div>
          </div>
        </Card>

        <Card>
          <p className="text-xs uppercase tracking-[0.28em] text-white/42">Prioritas</p>
          <div className="mt-5 space-y-3">
            {config.priorityList.map((item) => (
              <div key={`${item.title}-${item.status}`} className={`rounded-[22px] border p-4 ${serviceStatusPanelMap[item.status]} ${serviceStatusGlowMap[item.status]}`}>
                <div className="space-y-3">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <p className="min-w-0 text-sm font-semibold leading-5 text-white">{item.title}</p>
                    <StatusBadge status={item.status} />
                  </div>
                  <p className="text-sm leading-6 text-white/66">{item.note}</p>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </section>
    </div>
  );
}
