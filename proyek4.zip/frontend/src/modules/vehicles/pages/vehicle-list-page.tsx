import { Card } from '@/common/components/ui/card';

const vehicles = [
  { plate: 'AB 1234 JQ', unit: 'JAECOO J7 AWD', km: '12.420 km', color: 'Olive Gray' },
  { plate: 'AB 9908 OO', unit: 'JAECOO J8', km: '8.120 km', color: 'Moonlight Silver' },
  { plate: 'AB 8811 LM', unit: 'JAECOO J7 SHS', km: '5.930 km', color: 'Forest Black' },
];

export function VehicleListPage() {
  return (
    <div className="space-y-5">
      <div>
        <p className="text-xs uppercase tracking-[0.28em] text-white/42">Kendaraan</p>
        <h1 className="section-title mt-3">Kendaraan</h1>
      </div>
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {vehicles.map((item) => (
          <Card key={item.plate} className="overflow-hidden p-0">
            <img src="/assets/img3.webp" alt={item.unit} className="h-44 w-full object-cover" />
            <div className="p-5">
              <p className="text-xs uppercase tracking-[0.24em] text-white/42">{item.plate}</p>
              <h2 className="mt-3 text-xl font-semibold">{item.unit}</h2>
              <p className="mt-2 text-sm text-white/60">Warna: {item.color}</p>
              <p className="mt-1 text-sm text-white/60">Kilometer: {item.km}</p>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
