export const appRoutes = {
  main: [
    { path: '/dashboard', label: 'Dashboard' },
    { path: '/customers', label: 'Pelanggan' },
    { path: '/vehicles', label: 'Kendaraan' },
    { path: '/work-orders', label: 'Work Order' },
    { path: '/services', label: 'Servis' },
    { path: '/schedules', label: 'Jadwal' },
    { path: '/users', label: 'User' },
    { path: '/reports', label: 'Laporan' },
  ],
};
