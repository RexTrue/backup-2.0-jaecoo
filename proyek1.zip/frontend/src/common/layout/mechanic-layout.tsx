import { Outlet } from 'react-router-dom';

export function MechanicLayout() {
  return (
    <div className="min-h-screen bg-slate-50 p-4 md:p-6">
      <header className="mb-4 rounded-2xl bg-white p-4 shadow-sm">
        <h1 className="text-lg font-semibold">Panel Mekanik</h1>
      </header>
      <Outlet />
    </div>
  );
}
