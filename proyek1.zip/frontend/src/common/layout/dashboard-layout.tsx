import { Link, Outlet } from 'react-router-dom';
import { appRoutes } from '@/config/route.config';

export function DashboardLayout() {
  return (
    <div className="flex min-h-screen">
      <aside className="w-72 border-r bg-white p-6">
        <h1 className="mb-6 text-xl font-bold">Jaecoo Service</h1>
        <nav className="space-y-2">
          {appRoutes.main.map((route) => (
            <Link key={route.path} to={route.path} className="block rounded-lg px-3 py-2 hover:bg-slate-100">
              {route.label}
            </Link>
          ))}
        </nav>
      </aside>
      <main className="flex-1 p-6">
        <Outlet />
      </main>
    </div>
  );
}
