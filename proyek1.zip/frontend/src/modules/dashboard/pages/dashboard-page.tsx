import { Card } from '@/common/components/ui/card';

const metrics = [
  { label: 'Antrian Aktif', value: '12' },
  { label: 'Sedang Dikerjakan', value: '8' },
  { label: 'Selesai Hari Ini', value: '17' },
  { label: 'Terkendala', value: '3' },
];

export function DashboardPage() {
  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold">Dashboard Operasional</h1>
        <p className="text-sm text-slate-600">Ringkasan harian servis bengkel.</p>
      </header>
      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {metrics.map((item) => (
          <Card key={item.label}>
            <p className="text-sm text-slate-500">{item.label}</p>
            <p className="mt-2 text-3xl font-bold">{item.value}</p>
          </Card>
        ))}
      </section>
    </div>
  );
}
