import { Card } from '@/common/components/ui/card';
import { EmptyState } from '@/common/components/feedback/empty-state';

export function VehicleListPage() {
  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Kendaraan</h1>
        <p className="text-sm text-slate-600">Selaras dengan entitas Kendaraan: nomor rangka, plat nomor, kilometer, dan pemilik.</p>
      </div>
      <Card>
        <EmptyState title="List kendaraan" description="Tambahkan pencarian plat nomor, no rangka, serta panel riwayat servis kendaraan di halaman ini." />
      </Card>
    </div>
  );
}
