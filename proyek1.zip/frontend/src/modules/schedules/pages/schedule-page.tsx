import { Card } from '@/common/components/ui/card';

export function SchedulePage() {
  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Jadwal Servis</h1>
        <p className="text-sm text-slate-600">Tempat booking, kapasitas harian, dan slot kendaraan masuk.</p>
      </div>
      <Card>Kalender dan pengaturan slot servis ditempatkan di sini.</Card>
    </div>
  );
}
