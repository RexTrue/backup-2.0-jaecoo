import { Card } from '@/common/components/ui/card';
import { EmptyState } from '@/common/components/feedback/empty-state';

export function CustomerListPage() {
  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Pelanggan</h1>
        <p className="text-sm text-slate-600">Kelola data pemilik kendaraan berdasarkan model Pemilik.</p>
      </div>
      <Card>
        <EmptyState title="Tabel pelanggan" description="Siapkan table, filter NIK, nama, no HP, serta drawer form tambah/edit pelanggan di sini." />
      </Card>
    </div>
  );
}
