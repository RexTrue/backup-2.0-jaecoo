import { ServiceBoard } from '@/modules/services/components/service-board';
import { Service } from '@/common/types/domain';

const mockServices: Service[] = [
  { id_servis: 1, id_wo: 101, keluhan: 'Ganti oli dan cek rem', status: 'ANTRIAN', prioritas: 'NORMAL', createdAt: new Date().toISOString() },
  { id_servis: 2, id_wo: 102, keluhan: 'Mesin bergetar', status: 'DIKERJAKAN', prioritas: 'URGENT', createdAt: new Date().toISOString() },
  { id_servis: 3, id_wo: 103, keluhan: 'Test drive akhir', status: 'TEST_DRIVE', prioritas: 'HIGH', createdAt: new Date().toISOString() },
];

export function ServiceBoardPage() {
  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Board Servis</h1>
        <p className="text-sm text-slate-600">Tampilan utama progres servis per status.</p>
      </div>
      <ServiceBoard services={mockServices} />
    </div>
  );
}
