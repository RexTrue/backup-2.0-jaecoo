import { Card } from '@/common/components/ui/card';
import { StatusBadge } from '@/common/components/data-display/status-badge';
import { ServiceTimeline } from '@/modules/services/components/service-timeline';

const timeline = [
  { id_riwayat: 1, id_servis: 10, status: 'ANTRIAN' as const, waktu: new Date().toISOString() },
  { id_riwayat: 2, id_servis: 10, status: 'DIKERJAKAN' as const, waktu: new Date().toISOString() },
];

export function ServiceDetailPage() {
  return (
    <div className="grid gap-4 xl:grid-cols-[2fr_1fr]">
      <Card>
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-xs text-slate-500">WO #101</p>
            <h1 className="text-2xl font-bold">Servis Kendaraan</h1>
          </div>
          <StatusBadge status="DIKERJAKAN" />
        </div>
        <div className="mt-6 grid gap-4 md:grid-cols-2">
          <div>
            <h2 className="font-semibold">Kendaraan</h2>
            <p className="text-sm text-slate-600">Plat: B 1234 XYZ</p>
            <p className="text-sm text-slate-600">No rangka: MH123456789</p>
          </div>
          <div>
            <h2 className="font-semibold">Pelanggan</h2>
            <p className="text-sm text-slate-600">Nama: Budi Santoso</p>
            <p className="text-sm text-slate-600">No HP: 08123456789</p>
          </div>
        </div>
      </Card>
      <Card>
        <h2 className="mb-4 text-lg font-semibold">Timeline</h2>
        <ServiceTimeline items={timeline} />
      </Card>
    </div>
  );
}
