import { Card } from '@/common/components/ui/card';

export function ReportPage() {
  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Laporan</h1>
        <p className="text-sm text-slate-600">Analitik servis, performa mekanik, dan SLA operasional.</p>
      </div>
      <Card>Chart, filter periode, dan export laporan disiapkan di sini.</Card>
    </div>
  );
}
