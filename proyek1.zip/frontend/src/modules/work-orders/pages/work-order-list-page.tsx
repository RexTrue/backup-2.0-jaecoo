import { Card } from '@/common/components/ui/card';
import { EmptyState } from '@/common/components/feedback/empty-state';

export function WorkOrderListPage() {
  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Work Order</h1>
        <p className="text-sm text-slate-600">Daftar WO aktif berdasarkan kendaraan yang masuk bengkel.</p>
      </div>
      <Card>
        <EmptyState title="Tabel work order" description="Tambahkan filter status, tanggal masuk, pelanggan, kendaraan, dan aksi cetak/export." />
      </Card>
    </div>
  );
}
