import { Card } from '@/common/components/ui/card';

export function MechanicTaskPage() {
  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Tugas Saya</h1>
        <p className="text-sm text-slate-600">Versi UI yang lebih ringkas untuk mekanik di lantai kerja.</p>
      </div>
      <Card>
        <p className="font-semibold">Servis #102</p>
        <p className="text-sm text-slate-600">Keluhan: Mesin bergetar saat idle.</p>
      </Card>
    </div>
  );
}
