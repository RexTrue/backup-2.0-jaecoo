import { Card } from '@/common/components/ui/card';

export function UserManagementPage() {
  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Manajemen User</h1>
        <p className="text-sm text-slate-600">Kelola user internal berdasarkan role backend: ADMIN, MANAGER, FRONTLINE, MEKANIK.</p>
      </div>
      <Card>Tabel user, reset password, aktif/nonaktif, dan pengaturan role ada di sini.</Card>
    </div>
  );
}
