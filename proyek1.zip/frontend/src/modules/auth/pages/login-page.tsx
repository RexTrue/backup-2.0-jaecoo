import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button } from '@/common/components/ui/button';
import { Input } from '@/common/components/ui/input';
import { Card } from '@/common/components/ui/card';
import { useLogin, getErrorMessage } from '@/modules/auth/hooks/use-login';
import { createQuickDemoSession, demoCredentials } from '@/modules/auth/services/auth-api';
import { useAuthStore } from '@/modules/auth/store/auth-store';

const schema = z.object({
  email: z.string().email('Email tidak valid'),
  password: z.string().min(6, 'Password minimal 6 karakter'),
});

type FormValues = z.infer<typeof schema>;

export function LoginPage() {
  const navigate = useNavigate();
  const setSession = useAuthStore((state) => state.setSession);
  const loginMutation = useLogin();
  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { email: 'admin@service.com', password: 'Admin123!' },
  });

  useEffect(() => {
    if (loginMutation.isSuccess) {
      navigate('/dashboard', { replace: true });
    }
  }, [loginMutation.isSuccess, navigate]);

  const errorMessage = loginMutation.isError ? getErrorMessage(loginMutation.error) : null;

  return (
    <div>
      <h1 className="text-2xl font-bold">Masuk</h1>
      <p className="mt-2 text-sm text-slate-600">Gunakan akun internal untuk mengakses sistem servis.</p>
      <form className="mt-6 space-y-4" onSubmit={handleSubmit((values) => loginMutation.mutate(values))}>
        <div>
          <Input placeholder="Email" {...register('email')} />
          {errors.email && <p className="mt-1 text-xs text-red-600">{errors.email.message}</p>}
        </div>
        <div>
          <Input type="password" placeholder="Password" {...register('password')} />
          {errors.password && <p className="mt-1 text-xs text-red-600">{errors.password.message}</p>}
        </div>
        {errorMessage && <p className="rounded-xl bg-red-50 px-3 py-2 text-sm text-red-700">{errorMessage}</p>}
        <Button type="submit" className="w-full" disabled={loginMutation.isPending}>
          {loginMutation.isPending ? 'Memproses...' : 'Masuk'}
        </Button>
      </form>

      <Card className="mt-6 p-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h2 className="text-sm font-semibold text-slate-900">Akun demo siap pakai</h2>
            <p className="mt-1 text-xs text-slate-600">
              Jika backend auth belum aktif, frontend akan otomatis masuk memakai akun demo berikut.
            </p>
          </div>
          <Button
            type="button"
            variant="secondary"
            onClick={() => {
              const quickSession = createQuickDemoSession();
              setSession({ token: quickSession.accessToken, user: quickSession.user });
              navigate('/dashboard', { replace: true });
            }}
          >
            Masuk cepat
          </Button>
        </div>

        <div className="mt-4 space-y-3">
          {demoCredentials.map((credential) => (
            <div key={credential.email} className="rounded-xl border border-slate-200 p-3">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="text-sm font-medium text-slate-900">{credential.role}</p>
                  <p className="text-xs text-slate-600">{credential.email}</p>
                  <p className="text-xs text-slate-600">{credential.password}</p>
                </div>
                <Button
                  type="button"
                  variant="secondary"
                  onClick={() => {
                    setValue('email', credential.email, { shouldValidate: true });
                    setValue('password', credential.password, { shouldValidate: true });
                  }}
                >
                  Isi otomatis
                </Button>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
