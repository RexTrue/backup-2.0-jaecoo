# Jaecoo Service System Frontend

Struktur frontend ini dirancang untuk selaras dengan backend NestJS + Prisma dan model domain berikut:
- User
- Pemilik
- Kendaraan
- WorkOrder
- Servis
- JenisServis
- DetailServis
- CatatanMekanik
- RiwayatServis

## Prinsip desain
- feature-based architecture
- reusable common layer
- future-proof untuk multi-role (ADMIN, MANAGER, FRONTLINE, MEKANIK)
- selaras dengan operasi bengkel: dashboard, antrian servis, work order, kendaraan, pelanggan, user
- aman untuk dikembangkan bertahap tanpa membuat folder cepat berantakan

## Modul utama
- auth
- dashboard
- customers
- vehicles
- work-orders
- services
- mechanic
- schedules
- users
- reports

## Stack yang direkomendasikan
- React 18+
- TypeScript
- Vite
- React Router
- TanStack Query
- React Hook Form
- Zod
- Axios
- Zustand
- Tailwind CSS

## Catatan integrasi backend
Endpoint belum seluruhnya tersedia pada backend saat ini, jadi pada layer `services/` beberapa route disiapkan sebagai kontrak awal yang bisa disesuaikan saat endpoint final sudah stabil.


## Login demo siap pakai
Jika backend auth belum aktif, frontend tetap bisa dipakai memakai akun demo berikut:

- ADMIN — `admin@service.com` / `Admin123!`
- FRONTLINE — `frontline@service.com` / `Frontline123!`
- MANAGER — `manager@service.com` / `Manager123!`
- MEKANIK — `mechanic@service.com` / `Mechanic123!`

Frontend akan mencoba login ke backend lebih dulu. Jika endpoint auth belum tersedia atau backend tidak aktif, sistem otomatis fallback ke login demo.

Untuk memaksa hanya login backend, set `VITE_ENABLE_DEMO_AUTH=false`.
